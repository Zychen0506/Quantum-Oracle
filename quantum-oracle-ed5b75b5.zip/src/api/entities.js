import { base44 } from './base44Client';


export const TradingJournal = base44.entities.TradingJournal;

export const RiskProfile = base44.entities.RiskProfile;

export const VentureOpportunity = base44.entities.VentureOpportunity;

export const MembershipTier = base44.entities.MembershipTier;

export const SimulatedInvestment = base44.entities.SimulatedInvestment;

export const PartnerProject = base44.entities.PartnerProject;

export const Badge = base44.entities.Badge;



// auth sdk:
export const User = base44.auth;