import React, { useState, useEffect, useRef, useCallback } from 'react';
import { InvokeLLM } from '@/api/integrations';

// 備用市場數據
const fallbackMarketData = {
  timestamp: new Date().toISOString(),
  major_pairs: [
    {
      pair: "EUR/USD",
      current_price: "1.0892",
      change_percent: 0.12,
      trend: "up",
      volatility: 0.45
    },
    {
      pair: "GBP/USD", 
      current_price: "1.2734",
      change_percent: -0.08,
      trend: "down",
      volatility: 0.52
    },
    {
      pair: "USD/JPY",
      current_price: "149.82",
      change_percent: 0.23,
      trend: "up", 
      volatility: 0.38
    },
    {
      pair: "AUD/USD",
      current_price: "0.6598",
      change_percent: -0.15,
      trend: "down",
      volatility: 0.41
    }
  ],
  overall_sentiment: 0.15,
  volatility_index: 0.44,
  risk_level: "medium",
  market_news: [
    "聯準會維持利率政策不變",
    "歐洲央行暗示可能調整貨幣政策",
    "美元指數小幅上升", 
    "亞洲市場表現穩定"
  ],
  economic_indicators: {
    dxy: 104.25,
    vix: 18.42,
    gold_usd: 2032.50
  }
};

export default function MarketVigilance({ onMarketUpdate, onRiskAlert, onVentureMatch, onError }) {
  const [isActive, setIsActive] = useState(false);
  const intervalRef = useRef(null);
  const abortControllerRef = useRef(null);
  const alertThreshold = useRef({ volatility: 0.7, sentiment: -0.6 });

  const playCosmicChime = useCallback((type) => {
    try {
      const audioContext = new (window.AudioContext || window.webkitAudioContext)();
      
      const frequencies = {
        alert: [440, 554.37],
        opportunity: [261.63, 329.63, 392]
      };
      
      const freqs = frequencies[type] || frequencies.opportunity;
      
      freqs.forEach((freq, index) => {
        const oscillator = audioContext.createOscillator();
        const gainNode = audioContext.createGain();
        
        oscillator.connect(gainNode);
        gainNode.connect(audioContext.destination);
        
        oscillator.type = 'sine';
        oscillator.frequency.setValueAtTime(freq, audioContext.currentTime);
        
        gainNode.gain.setValueAtTime(0, audioContext.currentTime);
        gainNode.gain.linearRampToValueAtTime(0.1, audioContext.currentTime + 0.1);
        gainNode.gain.exponentialRampToValueAtTime(0.001, audioContext.currentTime + 1 + index * 0.2);
        
        oscillator.start(audioContext.currentTime + index * 0.1);
        oscillator.stop(audioContext.currentTime + 1 + index * 0.2);
      });
    } catch (error) {
      console.log('音效播放失敗:', error);
    }
  }, []);

  const fetchMarketData = useCallback(async () => {
    // 取消之前的請求
    if (abortControllerRef.current) {
      abortControllerRef.current.abort();
    }

    // 創建新的 AbortController
    abortControllerRef.current = new AbortController();

    try {
      // 先提供備用數據，確保界面有內容顯示
      const enhancedFallbackData = {
        ...fallbackMarketData,
        timestamp: new Date().toISOString(),
        cosmic_timestamp: Date.now(),
        source: 'fallback'
      };

      onMarketUpdate?.(enhancedFallbackData);

      // 嘗試獲取即時數據 - 簡化的schema
      const marketData = await InvokeLLM({
        prompt: `以繁體中文提供當前即時外匯市場數據，包括主要貨幣對（EUR/USD, GBP/USD, USD/JPY, AUD/USD）、整體市場情緒、波動率指數，以及影響外匯市場的關鍵經濟新聞。`,
        add_context_from_internet: true,
        response_json_schema: {
          type: "object",
          properties: {
            timestamp: { type: "string" },
            major_pairs: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  pair: { type: "string" },
                  current_price: { type: "string" },
                  change_percent: { type: "number" },
                  trend: { type: "string" },
                  volatility: { type: "number" }
                },
                required: ["pair", "current_price"]
              }
            },
            overall_sentiment: { type: "number" },
            volatility_index: { type: "number" },
            risk_level: { type: "string" },
            market_news: { 
              type: "array", 
              items: { type: "string" } 
            },
            economic_indicators: {
              type: "object",
              properties: {
                dxy: { type: "number" },
                vix: { type: "number" },
                gold_usd: { type: "number" }
              }
            }
          },
          required: ["timestamp", "major_pairs", "overall_sentiment"]
        }
      });

      // 如果成功獲取即時數據，更新界面
      if (marketData && !abortControllerRef.current?.signal.aborted) {
        marketData.cosmic_timestamp = Date.now();
        marketData.source = 'live';
        
        // 檢查風險警報
        if (marketData.volatility_index > alertThreshold.current.volatility ||
            marketData.overall_sentiment < alertThreshold.current.sentiment ||
            marketData.risk_level === 'extreme') {
          
          onRiskAlert?.({
            type: 'market_volatility',
            severity: marketData.risk_level,
            message: `量子警報：偵測到 ${marketData.risk_level} 市場狀況`,
            data: marketData
          });
          
          playCosmicChime('alert');
        }
        
        onMarketUpdate?.(marketData);
      }
      
    } catch (error) {
      if (error.name === 'AbortError') {
        console.log('市場數據請求被取消');
        return;
      }
      
      console.error('市場守夜服務出錯:', error);
      
      // 發生錯誤時，確保界面仍有數據顯示
      const errorFallbackData = {
        ...fallbackMarketData,
        timestamp: new Date().toISOString(),
        cosmic_timestamp: Date.now(),
        source: 'error_fallback'
      };
      
      onMarketUpdate?.(errorFallbackData);
      onError?.(new Error('即時數據暫時不可用，顯示備用數據'));
    }
  }, [onMarketUpdate, onRiskAlert, playCosmicChime, onError]);

  const scanForVentures = useCallback(async () => {
    try {
      // 提供備用投資機會數據
      const fallbackVentures = {
        scan_date: new Date().toISOString(),
        opportunities: [
          {
            title: "AI量化交易基金Delta",
            category: "ai_trading",
            description: "運用機器學習技術的新一代量化交易策略，專注於外匯市場套利機會。",
            minimum_investment: 500000,
            expected_return: 22,
            risk_level: "medium",
            exclusivity_level: "exclusive",
            match_score: 88,
            closing_date: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
            source: "量子預言家合作夥伴"
          },
          {
            title: "區塊鏈基礎設施投資",
            category: "blockchain", 
            description: "投資下一代區塊鏈基礎設施和 Layer 2 解決方案的專業基金。",
            minimum_investment: 1000000,
            expected_return: 35,
            risk_level: "high",
            exclusivity_level: "ultra_exclusive",
            match_score: 92,
            closing_date: new Date(Date.now() + 45 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
            source: "頂級創投合作"
          }
        ]
      };

      if (fallbackVentures.opportunities?.length > 0) {
        const highMatchVentures = fallbackVentures.opportunities.filter(v => v.match_score > 85);
        
        if (highMatchVentures.length > 0) {
          onVentureMatch?.({
            type: 'new_ventures',
            count: highMatchVentures.length,
            message: `${highMatchVentures.length} 個菁英機會正待您的審閱`,
            ventures: highMatchVentures
          });
          
          playCosmicChime('opportunity');
        }
        
        localStorage.setItem('latestVentures', JSON.stringify(fallbackVentures));
      }
      
    } catch (error) {
      console.error('掃描投資機會時出錯:', error);
    }
  }, [onVentureMatch, playCosmicChime]);

  const startVigilance = useCallback(() => {
    if (isActive) return;
    
    setIsActive(true);
    
    // 立即載入市場數據
    fetchMarketData();
    
    // 設定定期更新（降低頻率以減少請求失敗）
    intervalRef.current = setInterval(() => {
      fetchMarketData();
    }, 300000); // 改為 5 分鐘更新一次
    
    // 每日投資機會掃描
    const dailyVentureCheck = setInterval(() => {
      const now = new Date();
      const lastScan = localStorage.getItem('lastVentureScan');
      const lastScanDate = lastScan ? new Date(lastScan) : null;
      
      if (!lastScanDate || 
          (now.getHours() === 9 && now.getDate() !== lastScanDate.getDate())) {
        scanForVentures();
        localStorage.setItem('lastVentureScan', now.toISOString());
      }
    }, 3600000);

    return () => {
      clearInterval(dailyVentureCheck);
    };
  }, [isActive, fetchMarketData, scanForVentures]);

  useEffect(() => {
    startVigilance();
    return () => {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
      }
      if (abortControllerRef.current) {
        abortControllerRef.current.abort();
      }
    };
  }, [startVigilance]);

  return null;
}