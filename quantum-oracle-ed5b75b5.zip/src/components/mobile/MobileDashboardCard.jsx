import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ChevronDown, ChevronUp } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";

export default function MobileDashboardCard({ 
  metric, 
  onToggle, 
  isExpanded, 
  isMobile, 
  showOverview 
}) {
  const shouldShowExpandButton = isMobile && metric.expandable && !showOverview;

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      whileHover={{ scale: isMobile ? 1 : 1.02 }}
      whileTap={{ scale: 0.98 }}
    >
      <Card 
        className="border-0 transition-all duration-300 hover:shadow-lg cursor-pointer"
        style={{
          background: "rgba(26, 35, 50, 0.4)", 
          border: `1px solid ${metric.color}33`,
          boxShadow: isExpanded && isMobile ? `0 0 15px ${metric.color}30` : 'none'
        }}
        onClick={shouldShowExpandButton ? onToggle : undefined}
      >
        <CardHeader className="pb-2 md:pb-3">
          <div className="flex items-center justify-between">
            <CardTitle 
              className="text-sm font-semibold flex items-center gap-2"
              style={{color: metric.color}}
            >
              <metric.icon className="w-4 h-4" />
              {metric.title}
            </CardTitle>
            
            {shouldShowExpandButton && (
              <Button variant="ghost" size="sm" className="p-1 h-auto">
                {isExpanded ? 
                  <ChevronUp className="w-4 h-4" style={{color: metric.color}} /> :
                  <ChevronDown className="w-4 h-4" style={{color: metric.color}} />
                }
              </Button>
            )}
          </div>
        </CardHeader>
        
        <CardContent className="pt-0">
          {/* 基本指標 */}
          <div className="mb-2">
            <div className="text-2xl md:text-3xl font-bold text-white">
              {metric.value}
            </div>
            <div className="text-sm text-platinum/90 mt-1">
              {metric.subtitle}
            </div>
            {metric.change && (
              <motion.div 
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                className="text-xs font-semibold mt-1"
                style={{color: metric.color}}
              >
                {metric.change}
              </motion.div>
            )}
          </div>

          {/* 進度條 */}
          <div className="mt-3">
            <div className="w-full bg-black/20 rounded-full h-1.5">
              <motion.div
                initial={{ width: 0 }}
                animate={{ 
                  width: metric.id === 'risk' ? `${parseFloat(metric.value)}%` :
                         metric.id === 'performance' ? `${parseFloat(metric.value)}%` :
                         metric.id === 'emotion' ? `${Math.abs(parseFloat(metric.value)) * 50 + 50}%` :
                         '50%'
                }}
                transition={{ duration: 1, delay: 0.5 }}
                className="h-1.5 rounded-full"
                style={{ 
                  background: `linear-gradient(90deg, ${metric.color}, ${metric.color}80)` 
                }}
              />
            </div>
          </div>

          {/* 擴展內容 */}
          <AnimatePresence>
            {(isExpanded && isMobile) && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: "auto" }}
                exit={{ opacity: 0, height: 0 }}
                transition={{ duration: 0.2 }}
                className="mt-4 pt-4 border-t border-white/10"
              >
                <div className="space-y-2">
                  {metric.id === 'risk' && (
                    <div className="text-xs text-platinum/80">
                      <p>• AI 持續監控您的風險承受度</p>
                      <p>• 根據交易行為動態調整</p>
                      <p>• 即時市場條件影響分析</p>
                    </div>
                  )}
                  {metric.id === 'emotion' && (
                    <div className="text-xs text-platinum/80">
                      <p>• 情緒模式智能識別</p>
                      <p>• 恐懼與貪婪平衡分析</p>
                      <p>• 交易決策理性度評估</p>
                    </div>
                  )}
                  {metric.id === 'performance' && (
                    <div className="text-xs text-platinum/80">
                      <p>• 歷史交易成功率統計</p>
                      <p>• 盈虧比例詳細分析</p>
                      <p>• 策略優化建議</p>
                    </div>
                  )}
                  {metric.id === 'profit' && (
                    <div className="text-xs text-platinum/80">
                      <p>• 累計投資損益</p>
                      <p>• 資產配置效果</p>
                      <p>• 風險調整後收益</p>
                    </div>
                  )}
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </CardContent>
      </Card>
    </motion.div>
  );
}