import React, { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { BrainCircuit, Plus, Mic, Camera, BarChart3, MessageSquare } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';

export default function QuickActionFAB() {
  const [isExpanded, setIsExpanded] = useState(false);

  const quickActions = [
    {
      icon: Mic,
      label: '語音記錄',
      action: () => {
        window.dispatchEvent(new CustomEvent('startVoiceRecording'));
        setIsExpanded(false);
      },
      color: 'from-tech-blue to-blue-400'
    },
    {
      icon: BarChart3,
      label: '快速分析',
      href: createPageUrl('Journal'),
      color: 'from-trust-green to-green-400'
    },
    {
      icon: MessageSquare,
      label: 'AI助手',
      action: () => {
        window.dispatchEvent(new CustomEvent('openAIChat'));
        setIsExpanded(false);
      },
      color: 'from-warm-gold to-gold-accent'
    }
  ];

  const handleMainAction = () => {
    if (isExpanded) {
      setIsExpanded(false);
    } else {
      setIsExpanded(true);
    }
  };

  const handleBackdropClick = () => {
    setIsExpanded(false);
  };

  return (
    <>
      {/* 背景遮罩 */}
      <AnimatePresence>
        {isExpanded && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={handleBackdropClick}
            className="fixed inset-0 bg-black/20 z-40 md:hidden"
          />
        )}
      </AnimatePresence>

      {/* 快速動作按鈕們 */}
      <div className="fixed bottom-24 right-4 z-50 md:hidden">
        <AnimatePresence>
          {isExpanded && (
            <motion.div
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.8 }}
              className="space-y-3 mb-4"
            >
              {quickActions.map((action, index) => (
                <motion.div
                  key={action.label}
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: 20 }}
                  transition={{ delay: index * 0.1 }}
                >
                  {action.href ? (
                    <Link
                      to={action.href}
                      onClick={() => setIsExpanded(false)}
                      className="flex items-center gap-3 group"
                    >
                      <Card className="border-0 shadow-lg">
                        <CardContent className="p-2 px-4">
                          <span className="text-xs font-medium text-platinum whitespace-nowrap">
                            {action.label}
                          </span>
                        </CardContent>
                      </Card>
                      <div
                        className={`w-12 h-12 rounded-full bg-gradient-to-br ${action.color} flex items-center justify-center shadow-lg transition-transform group-hover:scale-110`}
                      >
                        <action.icon className="w-5 h-5 text-white" />
                      </div>
                    </Link>
                  ) : (
                    <button
                      onClick={action.action}
                      className="flex items-center gap-3 group"
                    >
                      <Card className="border-0 shadow-lg">
                        <CardContent className="p-2 px-4">
                          <span className="text-xs font-medium text-platinum whitespace-nowrap">
                            {action.label}
                          </span>
                        </CardContent>
                      </Card>
                      <div
                        className={`w-12 h-12 rounded-full bg-gradient-to-br ${action.color} flex items-center justify-center shadow-lg transition-transform group-hover:scale-110`}
                      >
                        <action.icon className="w-5 h-5 text-white" />
                      </div>
                    </button>
                  )}
                </motion.div>
              ))}
            </motion.div>
          )}
        </AnimatePresence>

        {/* 主要懸浮按鈕 */}
        <motion.button
          onClick={handleMainAction}
          whileHover={{ scale: 1.1 }}
          whileTap={{ scale: 0.95 }}
          className="w-14 h-14 rounded-full bg-gradient-to-br from-warm-gold to-gold-accent flex items-center justify-center shadow-2xl"
          style={{
            boxShadow: '0 8px 32px rgba(244, 185, 66, 0.4)'
          }}
        >
          <motion.div
            animate={{ rotate: isExpanded ? 45 : 0 }}
            transition={{ duration: 0.2 }}
          >
            {isExpanded ? (
              <Plus className="w-6 h-6 text-midnight-navy" />
            ) : (
              <BrainCircuit className="w-6 h-6 text-midnight-navy" />
            )}
          </motion.div>
        </motion.button>
      </div>
    </>
  );
}