import React from 'react';
import { motion } from 'framer-motion';
import { Shield, Award, Users, Star, CheckCircle } from 'lucide-react';
import { Card, CardContent } from "@/components/ui/card";

const TrustElements = ({ className }) => {
  const certifications = [
    { icon: Shield, text: "ISO 27001 認證", color: "var(--trust-green)" },
    { icon: Award, text: "金融科技創新獎", color: "var(--warm-gold)" },
    { icon: CheckCircle, text: "AI演算法認證", color: "var(--tech-blue)" }
  ];

  const testimonials = [
    {
      text: "風險控制系統讓我的投資決策更加理性，收益提升了35%。",
      author: "資深投資經理 L.",
      rating: 5
    },
    {
      text: "AI情緒分析功能非常準確，幫助我避免了多次衝動交易。",
      author: "量化分析師 C.",
      rating: 5
    },
    {
      text: "專業的市場預測模型，是我見過最精準的投資工具。",
      author: "基金經理 W.",
      rating: 5
    }
  ];

  return (
    <div className={className}>
      {/* 專業認證區域 */}
      <Card className="border-0 mb-6" 
            style={{background: "rgba(26, 35, 50, 0.3)", border: "1px solid rgba(229, 228, 226, 0.1)"}}>
        <CardContent className="p-4">
          <div className="flex items-center justify-center gap-8 flex-wrap">
            {certifications.map((cert, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.2 }}
                className="flex items-center gap-2 certification-badge"
              >
                <cert.icon className="w-5 h-5" style={{color: cert.color}} />
                <span className="text-sm font-medium" style={{color: "var(--platinum)"}}>{cert.text}</span>
              </motion.div>
            ))}
            
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.6 }}
              className="flex items-center gap-2"
            >
              <Users className="w-5 h-5" style={{color: "var(--tech-blue)"}} />
              <span className="text-sm font-medium" style={{color: "var(--platinum)"}}>
                1,200+ 專業投資人信賴
              </span>
            </motion.div>
          </div>
        </CardContent>
      </Card>

      {/* 匿名用戶見證區 */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
        {testimonials.map((testimonial, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: index * 0.15 }}
          >
            <Card className="border-0 h-full transition-all duration-300 hover:glow-platinum" 
                  style={{background: "rgba(26, 35, 50, 0.25)", border: "1px solid rgba(229, 228, 226, 0.1)"}}>
              <CardContent className="p-4">
                <div className="flex items-center gap-1 mb-2">
                  {[...Array(testimonial.rating)].map((_, i) => (
                    <Star key={i} className="w-3 h-3 fill-current" style={{color: "var(--warm-gold)"}} />
                  ))}
                </div>
                <p className="text-sm leading-relaxed mb-3" style={{color: "var(--platinum)"}}>
                  "{testimonial.text}"
                </p>
                <div className="text-xs opacity-70" style={{color: "var(--platinum)"}}>
                  - {testimonial.author}
                </div>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>
    </div>
  );
};

export default TrustElements;