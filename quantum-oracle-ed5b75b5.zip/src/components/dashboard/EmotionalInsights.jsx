import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { AlertTriangle, TrendingUp, TrendingDown, Heart, X } from 'lucide-react';
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

export default function EmotionalInsights() {
  const [emotionalAlerts, setEmotionalAlerts] = useState([]);

  useEffect(() => {
    const handleEmotionalAlert = (event) => {
      const alert = {
        id: Date.now(),
        timestamp: new Date(),
        ...event.detail
      };
      
      setEmotionalAlerts(prev => [alert, ...prev.slice(0, 2)]); // 最多顯示3個
      
      // 自動消失
      setTimeout(() => {
        dismissAlert(alert.id);
      }, 10000);
    };

    // 模擬情緒提醒
    const simulateEmotionalInsights = () => {
      const insights = [
        {
          type: 'greed_warning',
          message: '您的貪婪指數上升至75%，建議重新審視投資組合配置，避免過度集中。',
          severity: 'warning',
          icon: TrendingUp
        },
        {
          type: 'fear_alert',
          message: '市場波動可能引發恐慌情緒，建議保持理性，避免恐慌性拋售。',
          severity: 'info',
          icon: TrendingDown
        },
        {
          type: 'balance_tip',
          message: '您的情緒狀態相對穩定，這是做出理性投資決策的好時機。',
          severity: 'success',
          icon: Heart
        }
      ];
      
      // 隨機觸發情緒提醒
      if (Math.random() > 0.7) {
        const randomInsight = insights[Math.floor(Math.random() * insights.length)];
        window.dispatchEvent(new CustomEvent('emotionalAlert', {
          detail: randomInsight
        }));
      }
    };

    window.addEventListener('emotionalAlert', handleEmotionalAlert);
    
    // 定期模擬情緒洞察
    const interval = setInterval(simulateEmotionalInsights, 30000); // 30秒

    return () => {
      window.removeEventListener('emotionalAlert', handleEmotionalAlert);
      clearInterval(interval);
    };
  }, []);

  const dismissAlert = (id) => {
    setEmotionalAlerts(prev => prev.filter(alert => alert.id !== id));
  };

  const getAlertColor = (severity) => {
    const colors = {
      warning: '#ffa502',
      info: 'var(--tech-blue)',
      success: 'var(--trust-green)',
      error: '#ff4757'
    };
    return colors[severity] || 'var(--warm-gold)';
  };

  const getAlertTitle = (type) => {
    const titles = {
      greed_warning: '貪婪指數警告',
      fear_alert: '恐慌情緒提醒',
      balance_tip: '情緒平衡提示',
      risk_alert: '風險評估提醒'
    };
    return titles[type] || '情緒洞察';
  };

  if (emotionalAlerts.length === 0) return null;

  return (
    <div className="fixed top-20 right-4 z-40 space-y-3 max-w-sm">
      <AnimatePresence>
        {emotionalAlerts.map((alert) => (
          <motion.div
            key={alert.id}
            initial={{ opacity: 0, x: 300, scale: 0.8 }}
            animate={{ opacity: 1, x: 0, scale: 1 }}
            exit={{ opacity: 0, x: 300, scale: 0.8 }}
          >
            <Card 
              className="border-0 relative overflow-hidden shadow-2xl"
              style={{
                background: "linear-gradient(135deg, rgba(10, 15, 26, 0.95) 0%, rgba(26, 35, 50, 0.95) 100%)",
                border: `1px solid ${getAlertColor(alert.severity)}50`,
                backdropFilter: "blur(10px)"
              }}
            >
              <motion.div
                animate={{
                  opacity: [0.3, 0.7, 0.3]
                }}
                transition={{
                  duration: 2,
                  repeat: Infinity,
                  ease: "easeInOut"
                }}
                className="absolute inset-0 rounded-lg"
                style={{
                  background: `linear-gradient(135deg, ${getAlertColor(alert.severity)}20 0%, transparent 50%)`
                }}
              />
              
              <CardContent className="relative p-4">
                <div className="flex items-start gap-3">
                  <div className="mt-1">
                    {alert.icon ? (
                      <alert.icon className="w-5 h-5" style={{color: getAlertColor(alert.severity)}} />
                    ) : (
                      <AlertTriangle className="w-5 h-5" style={{color: getAlertColor(alert.severity)}} />
                    )}
                  </div>
                  
                  <div className="flex-1 min-w-0">
                    <h4 
                      className="font-semibold text-sm mb-1"
                      style={{color: getAlertColor(alert.severity)}}
                    >
                      {getAlertTitle(alert.type)}
                    </h4>
                    
                    <p className="text-sm leading-relaxed text-white font-medium mb-2">
                      {alert.message}
                    </p>
                    
                    <div className="text-xs mt-2 opacity-70" style={{color: "var(--platinum-light)"}}>
                      {alert.timestamp.toLocaleTimeString()}
                    </div>
                  </div>

                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => dismissAlert(alert.id)}
                    className="text-gray-400 hover:text-white p-1 h-auto"
                  >
                    <X className="w-4 h-4" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </AnimatePresence>
    </div>
  );
}