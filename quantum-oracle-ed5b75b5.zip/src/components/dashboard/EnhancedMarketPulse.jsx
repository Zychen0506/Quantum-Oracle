import React, { useState, useEffect } from 'react';
import { TrendingUp, TrendingDown, Activity, Zap, Globe } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { Tooltip, TooltipContent, TooltipTrigger } from "@/components/ui/tooltip";

export default function EnhancedMarketPulse({ marketData, className }) {
  const [pulseIntensity, setPulseIntensity] = useState(0.5);
  const [lastUpdate, setLastUpdate] = useState(null);
  const [newDataReceived, setNewDataReceived] = useState(false);
  const [dataSource, setDataSource] = useState('live');

  useEffect(() => {
    if (marketData) {
      setLastUpdate(new Date());
      setNewDataReceived(true);
      setDataSource(marketData.source || 'live');
      
      const intensity = Math.min(marketData.volatility_index || 0.5, 1);
      setPulseIntensity(intensity);
      
      setTimeout(() => setNewDataReceived(false), 2000);
    }
  }, [marketData]);

  if (!marketData) {
    return (
      <div className={`${className} animate-pulse`}>
        <div className="h-64 bg-gray-700/50 rounded-xl flex items-center justify-center">
          <div className="text-center">
            <Zap className="w-8 h-8 mx-auto mb-2 opacity-40" style={{color: "var(--warm-gold)"}} />
            <p className="text-sm opacity-60" style={{color: "var(--platinum)"}}>
              正在連接宇宙市場流...
            </p>
          </div>
        </div>
      </div>
    );
  }

  const getSentimentIcon = (sentiment) => {
    if (sentiment > 0.2) return <TrendingUp className="w-5 h-5 text-green-400" />;
    if (sentiment < -0.2) return <TrendingDown className="w-5 h-5 text-red-400" />;
    return <Activity className="w-5 h-5" style={{color: "var(--warm-gold)"}} />;
  };

  const getRiskColor = (level) => {
    const colors = {
      low: 'var(--tech-blue)',
      medium: 'var(--warm-gold)',
      high: '#ff6b6b',
      extreme: '#ff4757'
    };
    return colors[level] || 'var(--platinum)';
  };
  
  const getRiskText = (level) => {
    const texts = {
      low: '低風險',
      medium: '中風險',
      high: '高風險',
      extreme: '極高風險'
    };
    return texts[level] || '未知風險';
  };

  const getDataSourceText = (source) => {
    const texts = {
      live: '即時更新',
      fallback: '備用數據',
      error_fallback: '離線模式'
    };
    return texts[source] || '即時更新';
  };

  const getDataSourceColor = (source) => {
    const colors = {
      live: 'var(--tech-blue)',
      fallback: 'var(--warm-gold)',
      error_fallback: '#ff6b6b'
    };
    return colors[source] || 'var(--tech-blue)';
  };

  return (
    <div className={`${className} relative`}>
      {/* Data source indicator */}
      <AnimatePresence>
        {(newDataReceived || dataSource !== 'live') && (
          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.8 }}
            className="absolute -top-2 -right-2 z-10 flex items-center gap-2 px-3 py-1 rounded-full text-xs font-medium"
            style={{
              background: `linear-gradient(135deg, ${getDataSourceColor(dataSource)} 0%, ${getDataSourceColor(dataSource)}80 100%)`,
              color: dataSource === 'live' ? "#fff" : "var(--midnight-navy)"
            }}
          >
            <Globe className={`w-3 h-3 ${dataSource === 'live' ? 'animate-spin' : ''}`} />
            {getDataSourceText(dataSource)}
          </motion.div>
        )}
      </AnimatePresence>

      <div className="mb-6">
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center gap-3">
            <Tooltip>
              <TooltipTrigger asChild>
                <div className="flex items-center gap-2 cursor-help">
                  {getSentimentIcon(marketData.overall_sentiment)}
                  <h3 className="text-lg font-medium" style={{color: "var(--warm-gold)"}}>
                    宇宙市場脈動
                  </h3>
                </div>
              </TooltipTrigger>
              <TooltipContent 
                className="max-w-xs border-0"
                style={{
                  background: "rgba(10, 15, 26, 0.95)",
                  border: "1px solid rgba(255, 215, 0, 0.3)"
                }}
              >
                <div className="text-xs" style={{color: "var(--warm-gold)"}}>
                  從全球外匯流中收集的市場情報，結晶為菁英交易決策的可行洞見。
                  {dataSource !== 'live' && (
                    <div className="mt-1 text-orange-300">
                      目前使用備用數據源
                    </div>
                  )}
                </div>
              </TooltipContent>
            </Tooltip>
          </div>
          
          <div className="flex items-center gap-3">
            <Tooltip>
              <TooltipTrigger asChild>
                <div 
                  className="px-3 py-1 rounded-full text-xs font-semibold cursor-help"
                  style={{
                    background: `${getRiskColor(marketData.risk_level)}20`,
                    border: `1px solid ${getRiskColor(marketData.risk_level)}50`,
                    color: getRiskColor(marketData.risk_level)
                  }}
                >
                  {getRiskText(marketData.risk_level)}
                </div>
              </TooltipTrigger>
              <TooltipContent style={{background: "rgba(10, 15, 26, 0.95)", border: "1px solid rgba(255, 215, 0, 0.3)"}}>
                <div className="text-xs" style={{color: "var(--warm-gold)"}}>
                  基於波動率指數和全球經濟指標的當前市場風險評估
                </div>
              </TooltipContent>
            </Tooltip>
          </div>
        </div>
        
        <div className="flex items-center justify-between">
          <p className="text-sm opacity-60" style={{color: "var(--platinum)"}}>
            來自量子交易領域的市場訊息
          </p>
          {lastUpdate && (
            <div className="text-xs opacity-50" style={{color: "var(--tech-blue)"}}>
              更新於 {lastUpdate.toLocaleTimeString()}
            </div>
          )}
        </div>
      </div>

      {/* Enhanced pulse visualization */}
      <div className="relative mb-6 flex items-center justify-center">
        <motion.div
          animate={{
            scale: [1, 1 + pulseIntensity * 0.1, 1],
            opacity: [0.6, 1, 0.6]
          }}
          transition={{
            duration: 2,
            repeat: Infinity,
            ease: "easeInOut"
          }}
          className="w-20 h-20 rounded-full border-2 flex items-center justify-center"
          style={{
            borderColor: getRiskColor(marketData.risk_level),
            background: `radial-gradient(circle, ${getRiskColor(marketData.risk_level)}10 0%, transparent 70%)`
          }}
        >
          <Zap className="w-8 h-8" style={{color: getRiskColor(marketData.risk_level)}} />
        </motion.div>
        
        {/* Pulse rings */}
        {[1, 2, 3].map((ring) => (
          <motion.div
            key={ring}
            animate={{
              scale: [1, 2.5],
              opacity: [0.5, 0]
            }}
            transition={{
              duration: 3,
              repeat: Infinity,
              delay: ring * 0.5,
              ease: "easeOut"
            }}
            className="absolute w-20 h-20 rounded-full border"
            style={{
              borderColor: getRiskColor(marketData.risk_level)
            }}
          />
        ))}
      </div>

      {/* Market pairs */}
      <div className="space-y-3">
        {marketData.major_pairs?.slice(0, 4).map((pair) => (
          <motion.div 
            key={pair.pair}
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            className="p-4 rounded-xl transition-all duration-300 hover:glow-platinum border"
            style={{ 
              background: "rgba(26, 35, 50, 0.4)", 
              border: "1px solid rgba(224, 224, 224, 0.2)" 
            }}
          >
            <div className="flex justify-between items-center">
              <div className="flex items-center gap-3">
                <span className="font-semibold" style={{color: "var(--warm-gold)"}}>{pair.pair}</span>
                {pair.volatility > 0.7 && (
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <Zap className="w-4 h-4 text-yellow-400 animate-pulse cursor-help" />
                    </TooltipTrigger>
                    <TooltipContent style={{background: "rgba(10, 15, 26, 0.95)", border: "1px solid rgba(255, 215, 0, 0.3)"}}>
                      <div className="text-xs" style={{color: "var(--warm-gold)"}}>
                        偵測到高波動性 - 請加強謹慎
                      </div>
                    </TooltipContent>
                  </Tooltip>
                )}
              </div>
              <div className="text-right">
                <div className="font-mono text-sm" style={{color: "var(--platinum)"}}>{pair.current_price}</div>
                <div className={`text-xs font-semibold ${pair.change_percent >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                  {pair.change_percent >= 0 ? '+' : ''}{pair.change_percent?.toFixed(2)}%
                </div>
              </div>
            </div>
            
            {/* Trend indicator */}
            <div className="mt-2 flex items-center justify-between">
              <div className={`text-xs px-2 py-1 rounded-full ${
                pair.trend === 'up' ? 'bg-green-500/20 text-green-300' :
                pair.trend === 'down' ? 'bg-red-500/20 text-red-300' :
                'bg-gray-500/20 text-gray-300'
              }`}>
                {pair.trend === 'up' ? '上升趨勢' : pair.trend === 'down' ? '下降趨勢' : '橫盤整理'}
              </div>
              
              <div className="flex items-center gap-2">
                <div className="text-xs opacity-60" style={{color: "var(--platinum)"}}>波動性:</div>
                <div className="w-16 h-1 bg-black/20 rounded-full overflow-hidden">
                  <motion.div
                    initial={{ width: 0 }}
                    animate={{ width: `${(pair.volatility || 0) * 100}%` }}
                    transition={{ duration: 1 }}
                    className="h-full rounded-full"
                    style={{
                      background: pair.volatility > 0.7 ? '#ff4757' : 
                                 pair.volatility > 0.4 ? 'var(--warm-gold)' : 'var(--tech-blue)'
                    }}
                  />
                </div>
              </div>
            </div>
          </motion.div>
        ))}
      </div>

      {/* Economic indicators */}
      {marketData.economic_indicators && (
        <div className="mt-6 p-4 rounded-xl border" style={{background: "rgba(26, 35, 50, 0.4)", border: "1px solid rgba(0, 210, 255, 0.3)"}}>
          <h4 className="text-sm font-semibold mb-3" style={{color: "var(--tech-blue)"}}>經濟量子狀態</h4>
          <div className="grid grid-cols-3 gap-4 text-xs">
            {Object.entries(marketData.economic_indicators).map(([key, value]) => (
              <div key={key} className="text-center">
                <div className="font-mono font-semibold" style={{color: "var(--platinum)"}}>{value}</div>
                <div className="opacity-60 uppercase" style={{color: "var(--platinum)"}}>{key.replace('_', ' ')}</div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}