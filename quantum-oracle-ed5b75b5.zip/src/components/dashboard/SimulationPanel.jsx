
import React, { useState, useRef } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Mic, MicOff, Zap, Sparkles } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { InvokeLLM } from "@/api/integrations";

const invokeLLMWithRetry = async (params, retries = 3, delay = 1000) => {
  for (let i = 0; i < retries; i++) {
    try {
      return await InvokeLLM(params);
    } catch (error) {
      if (i === retries - 1) {
        throw error; // Re-throw if it's the last retry
      }
      // Wait before retrying, with increasing delay
      await new Promise(res => setTimeout(res, delay * (i + 1)));
    }
  }
};

export default function SimulationPanel({ onSimulationResult, className }) {
  const [isSimulating, setIsSimulating] = useState(false);
  const [isRecording, setIsRecording] = useState(false);
  const [simulationText, setSimulationText] = useState('');
  const [recentSimulations, setRecentSimulations] = useState([]);
  const recognitionRef = useRef(null);

  React.useEffect(() => {
    initializeSpeechRecognition();
    return () => recognitionRef.current?.stop();
  }, []);

  const initializeSpeechRecognition = () => {
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (SpeechRecognition) {
      const recognition = new SpeechRecognition();
      recognition.lang = 'zh-TW';
      recognition.continuous = true;
      recognition.interimResults = true;
      recognition.onresult = (event) => {
        const transcript = Array.from(event.results).map(result => result[0].transcript).join('');
        setSimulationText(transcript);
      };
      recognition.onend = () => setIsRecording(false);
      recognitionRef.current = recognition;
    }
  };

  const handleVoiceRecording = () => {
    if (!recognitionRef.current) return alert('此環境不支援語音輸入。');
    if (isRecording) {
      recognitionRef.current.stop();
    } else {
      recognitionRef.current.start();
      setIsRecording(true);
    }
  };

  const runSimulation = async () => {
    if (!simulationText.trim()) return;
    
    setIsSimulating(true);
    try {
      const analysis = await invokeLLMWithRetry({
        prompt: `以繁體中文分析此筆模擬外匯交易場景以供菁英驗證：「${simulationText}」。提供詳細的情緒分析、風險評估、情緒狀態偵測和策略洞見。計算對整體風險畫像的影響並提供個人化建議。`,
        response_json_schema: {
          type: "object",
          properties: {
            sentiment_score: { type: "number", minimum: -1, maximum: 1 },
            emotional_state: { type: "string", enum: ["confident", "anxious", "excited", "fearful", "neutral", "greedy", "disciplined"] },
            risk_impact: { type: "number", minimum: -20, maximum: 20 },
            risk_breakdown: {
              type: "object",
              properties: {
                volatility_tolerance: { type: "number" },
                position_sizing: { type: "number" },
                emotional_stability: { type: "number" },
                market_timing: { type: "number" }
              }
            },
            strategy_whisper: { type: "string" },
            ai_insights: { type: "string" },
            trade_pair: { type: "string" },
            projected_outcome: { type: "string", enum: ["positive", "negative", "neutral"] }
          }
        }
      });

      const simulationResult = {
        id: Date.now(),
        input: simulationText,
        timestamp: new Date().toISOString(),
        ...analysis
      };

      setRecentSimulations(prev => [simulationResult, ...prev.slice(0, 4)]);
      onSimulationResult(simulationResult);
      setSimulationText('');
      
    } catch (error) {
      console.error('模擬時出錯 (重試後):', error);
      // 可選：向用戶顯示錯誤提示
    }
    setIsSimulating(false);
  };

  const quickSimulations = [
    "在消息發布後謹慎地賣出歐元/美元",
    "在突破時充滿信心地買入英鎊/日元", 
    "因害怕反轉而提早平倉",
    "以紀律性的耐心持有度過回撤"
  ];
  
  const getProjectedOutcomeText = (outcome) => {
      const texts = {
          positive: '正面',
          negative: '負面',
          neutral: '中性'
      }
      return texts[outcome] || '模擬';
  }
  
  const getSentimentText = (score) => {
      if(score > 0.1) return '樂觀';
      if(score < -0.1) return '謹慎';
      return '中性';
  }

  return (
    <Card className={`border-0 ${className}`} style={{background: "rgba(42, 42, 42, 0.3)", border: "1px solid rgba(212, 175, 55, 0.2)"}}>
      <CardHeader>
        <CardTitle className="flex items-center gap-3" style={{color: "var(--gold)"}}>
          <Zap className="w-5 h-5" />
          菁英驗證聖殿
        </CardTitle>
        <p className="text-sm opacity-70" style={{color: "var(--silver)"}}>
          測試交易場景，見證即時的風險結晶
        </p>
      </CardHeader>
      
      <CardContent className="space-y-6">
        <div className="relative">
          <Textarea
            value={simulationText}
            onChange={(e) => setSimulationText(e.target.value)}
            placeholder="描述一個交易場景...（例如：『因謹慎而賣出歐元/美元』）"
            rows={3}
            className="bg-black/20 border-gray-600 text-white resize-none pr-12"
          />
          <Button
            type="button"
            size="icon"
            variant="ghost"
            onClick={handleVoiceRecording}
            className={`absolute top-2 right-2 rounded-full transition-all duration-300 ${
              isRecording ? 'text-red-500 animate-pulse glow-gold' : 'text-gray-400 hover:text-gold'
            }`}
          >
            {isRecording ? <MicOff className="w-5 h-5" /> : <Mic className="w-5 h-5" />}
          </Button>
        </div>

        <div className="flex gap-2">
          <Button
            onClick={runSimulation}
            disabled={isSimulating || !simulationText.trim()}
            className="flex-1 transition-all duration-300 glow-gold"
            style={{background: "linear-gradient(135deg, var(--gold) 0%, var(--gold-light) 100%)", color: "#000"}}
          >
            {isSimulating ? (
              <>
                <Sparkles className="w-4 h-4 mr-2 animate-spin" />
                結晶中...
              </>
            ) : (
              <>
                <Zap className="w-4 h-4 mr-2" />
                模擬與分析
              </>
            )}
          </Button>
        </div>

        <div className="grid grid-cols-2 gap-2">
          <p className="text-xs font-medium mb-2 col-span-2" style={{color: "var(--silver-light)"}}>快速測試:</p>
          {quickSimulations.map((sim, index) => (
            <Button
              key={index}
              variant="outline"
              size="sm"
              onClick={() => setSimulationText(sim)}
              className="text-xs p-2 h-auto text-left justify-start transition-all duration-200 hover:glow-silver"
              style={{
                background: "rgba(26, 26, 26, 0.5)", 
                borderColor: "rgba(192, 192, 192, 0.1)",
                color: "var(--silver)"
              }}
            >
              {sim}
            </Button>
          ))}
        </div>

        <AnimatePresence>
          {recentSimulations.length > 0 && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="space-y-3"
            >
              <div className="flex items-center gap-2 mb-3">
                <Sparkles className="w-4 h-4" style={{color: "var(--ethereal-blue)"}} />
                <h4 className="text-sm font-medium" style={{color: "var(--ethereal-blue)"}}>近期模擬</h4>
              </div>
              {recentSimulations.slice(0, 3).map((sim) => (
                <motion.div
                  key={sim.id}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  className="p-3 rounded-lg border"
                  style={{background: "rgba(26, 26, 26, 0.3)", border: "1px solid rgba(74, 144, 226, 0.2)"}}
                >
                  <div className="flex items-center gap-2 mb-2">
                    <Badge 
                      className={`text-xs ${sim.projected_outcome === 'positive' ? 'bg-green-500/20 text-green-300' : sim.projected_outcome === 'negative' ? 'bg-red-500/20 text-red-300' : 'bg-gray-500/20 text-gray-300'}`}
                    >
                      {sim.trade_pair || getProjectedOutcomeText(sim.projected_outcome)}
                    </Badge>
                    <div className={`text-xs font-semibold ${sim.sentiment_score > 0.1 ? 'text-green-400' : sim.sentiment_score < -0.1 ? 'text-red-400' : 'text-yellow-400'}`}>
                      {getSentimentText(sim.sentiment_score)} ({sim.sentiment_score.toFixed(2)})
                    </div>
                  </div>
                  <p className="text-xs opacity-80 mb-2" style={{color: "var(--silver)"}}>{sim.input}</p>
                  {sim.strategy_whisper && (
                    <div className="p-2 rounded text-xs" style={{background: "rgba(212, 175, 55, 0.1)", border: "1px solid rgba(212, 175, 55, 0.2)"}}>
                      <strong style={{color: "var(--gold)"}}>神諭低語：</strong> <span style={{color: "var(--silver)"}}>{sim.strategy_whisper}</span>
                    </div>
                  )}
                </motion.div>
              ))}
            </motion.div>
          )}
        </AnimatePresence>
      </CardContent>
    </Card>
  );
}
