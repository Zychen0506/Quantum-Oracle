import React, { useRef, useEffect, useState } from 'react';
import * as THREE from 'three';
import { motion, AnimatePresence } from 'framer-motion';
import { Tooltip, TooltipContent, TooltipTrigger, TooltipProvider } from "@/components/ui/tooltip";

export default function EnhancedRiskOrb({ 
  riskScore = 50, 
  volatility = 0.5, 
  riskBreakdown = {}, 
  isSimulating = false,
  className 
}) {
  const mountRef = useRef(null);
  const [showBreakdown, setShowBreakdown] = useState(false);
  const [orbData, setOrbData] = useState({ riskScore, volatility, riskBreakdown });

  useEffect(() => {
    const timeout = setTimeout(() => {
      setOrbData({ riskScore, volatility, riskBreakdown });
    }, isSimulating ? 0 : 300);
    
    return () => clearTimeout(timeout);
  }, [riskScore, volatility, riskBreakdown, isSimulating]);

  useEffect(() => {
    let mount = mountRef.current;
    if (!mount) return;

    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(75, mount.clientWidth / mount.clientHeight, 0.1, 1000);
    const renderer = new THREE.WebGLRenderer({ alpha: true, antialias: true });
    renderer.setSize(mount.clientWidth, mount.clientHeight);
    renderer.setPixelRatio(window.devicePixelRatio);
    mount.appendChild(renderer.domElement);

    const getRiskColor = (score) => {
      const t = score / 100;
      const techBlue = new THREE.Color(0x00D2FF);
      const warmGold = new THREE.Color(0xF4B942);
      const alertRed = new THREE.Color(0xff4757);
      if (t < 0.5) return techBlue.lerp(warmGold, t * 2);
      return warmGold.lerp(alertRed, (t - 0.5) * 2);
    };

    const currentColor = getRiskColor(orbData.riskScore);

    const coreGeometry = new THREE.SphereGeometry(1, 64, 64);
    const coreMaterial = new THREE.MeshPhongMaterial({
      color: currentColor,
      emissive: currentColor,
      emissiveIntensity: 0.4,
      shininess: 120,
      transparent: true,
      opacity: 0.92
    });
    const core = new THREE.Mesh(coreGeometry, coreMaterial);
    scene.add(core);
    
    const shells = [];
    for (let i = 1; i <= 3; i++) {
      const shellGeometry = new THREE.SphereGeometry(1 + i * 0.1, 32, 32);
      const shellMaterial = new THREE.MeshBasicMaterial({
        color: currentColor,
        transparent: true,
        opacity: 0.05 * i,
        wireframe: true
      });
      const shell = new THREE.Mesh(shellGeometry, shellMaterial);
      shells.push(shell);
      scene.add(shell);
    }
    
    const particleGeometry = new THREE.BufferGeometry();
    const particleCount = Math.floor(orbData.riskScore * 2);
    const positions = new Float32Array(particleCount * 3);
    
    for (let i = 0; i < particleCount; i++) {
      const radius = 1.5 + Math.random() * 0.5;
      const theta = Math.random() * Math.PI * 2;
      const phi = Math.acos(2 * Math.random() - 1);
      
      positions[i * 3] = radius * Math.sin(phi) * Math.cos(theta);
      positions[i * 3 + 1] = radius * Math.sin(phi) * Math.sin(theta);
      positions[i * 3 + 2] = radius * Math.cos(phi);
    }
    
    particleGeometry.setAttribute('position', new THREE.BufferAttribute(positions, 3));
    
    const particleMaterial = new THREE.PointsMaterial({
      color: currentColor,
      size: 0.03,
      transparent: true,
      opacity: 0.6
    });
    
    const particles = new THREE.Points(particleGeometry, particleMaterial);
    scene.add(particles);

    const pointLight = new THREE.PointLight(0xffffff, 0.8);
    pointLight.position.set(5, 5, 5);
    scene.add(pointLight);
    
    const ambientLight = new THREE.AmbientLight(0x404040, 0.6);
    scene.add(ambientLight);

    const rimLight = new THREE.PointLight(currentColor.getHex(), 1.0, 10);
    rimLight.position.set(-3, 3, 3);
    scene.add(rimLight);

    camera.position.z = 3.5;

    let animationFrameId;
    const animate = () => {
      animationFrameId = requestAnimationFrame(animate);
      
      const time = Date.now() * 0.001;
      const intensityMultiplier = isSimulating ? 3 : 1;
      
      core.rotation.y += 0.003 * intensityMultiplier;
      core.rotation.x += 0.001 * intensityMultiplier;
      
      const pulse = 1 + Math.sin(time * 2) * orbData.volatility * 0.1 * intensityMultiplier;
      core.scale.setScalar(pulse);
      
      shells.forEach((shell, index) => {
        shell.rotation.y -= 0.002 * (index + 1) * intensityMultiplier;
        shell.rotation.x += 0.001 * (index + 1) * intensityMultiplier;
        
        const shellPulse = 1 + Math.sin(time * 1.5 + index) * 0.05 * intensityMultiplier;
        shell.scale.setScalar(shellPulse);
      });
      
      particles.rotation.y += 0.001 * intensityMultiplier;
      particles.rotation.z += 0.0005 * intensityMultiplier;
      
      coreMaterial.emissiveIntensity = 0.3 + (isSimulating ? Math.sin(time * 10) * 0.3 : 0);
      
      renderer.render(scene, camera);
    };
    animate();

    const handleResize = () => {
      camera.aspect = mount.clientWidth / mount.clientHeight;
      camera.updateProjectionMatrix();
      renderer.setSize(mount.clientWidth, mount.clientHeight);
    };
    window.addEventListener('resize', handleResize);

    return () => {
      window.removeEventListener('resize', handleResize);
      cancelAnimationFrame(animationFrameId);
      if (mount.contains(renderer.domElement)) {
        mount.removeChild(renderer.domElement);
      }
      renderer.dispose();
    };
  }, [orbData, isSimulating]);

  const breakdown = orbData.riskBreakdown || {};

  const getBreakdownLabel = (key) => {
    const labels = {
      volatility_tolerance: '波動容忍度',
      position_sizing: '倉位管理',
      emotional_stability: '情緒穩定性',
      market_timing: '市場時機'
    };
    return labels[key] || key;
  };
  
  const getBreakdownTooltip = (key) => {
    const tooltips = {
      volatility_tolerance: '衡量您在市場波動中保持情緒穩定的能力',
      position_sizing: '評估您的倉位管理和資金分配方法',
      emotional_stability: '評估您在不利市場條件下的心理韌性',
      market_timing: '分析您在最佳時機進出場的能力'
    };
    return tooltips[key] || '';
  };

  return (
    <TooltipProvider>
      <div className="relative">
        <Tooltip>
          <TooltipTrigger asChild>
            <div 
              ref={mountRef} 
              className={`cursor-pointer transition-all duration-500 ${className} ${isSimulating ? 'animate-pulse' : ''}`}
              style={{ width: '280px', height: '280px' }}
              onMouseEnter={() => setShowBreakdown(true)}
              onMouseLeave={() => setShowBreakdown(false)}
            />
          </TooltipTrigger>
          <TooltipContent 
            side="right" 
            className="max-w-xs p-4 border-0"
            style={{
              background: "linear-gradient(135deg, rgba(10, 15, 26, 0.95) 0%, rgba(26, 35, 50, 0.95) 100%)",
              border: "1px solid rgba(244, 185, 66, 0.4)"
            }}
          >
            <div className="space-y-2">
              <h4 className="font-semibold text-sm" style={{color: "var(--warm-gold)"}}>
                量化風險分析
              </h4>
              <p className="text-xs opacity-90" style={{color: "var(--platinum)"}}>
                運用深度學習算法即時分析您的風險承受能力，結合市場波動與投資行為模式。
              </p>
              <div className="text-xs mt-2" style={{color: "var(--tech-blue)"}}>
                <strong>當前風險評級：</strong> {orbData.riskScore.toFixed(0)}/100
              </div>
            </div>
          </TooltipContent>
        </Tooltip>

        <AnimatePresence>
          {showBreakdown && Object.keys(breakdown).length > 0 && (
            <motion.div
              initial={{ opacity: 0, x: 20, scale: 0.9 }}
              animate={{ opacity: 1, x: 0, scale: 1 }}
              exit={{ opacity: 0, x: 20, scale: 0.9 }}
              className="absolute -right-4 top-1/2 transform -translate-y-1/2 w-72 p-5 rounded-xl border"
              style={{
                background: "linear-gradient(135deg, rgba(10, 15, 26, 0.95) 0%, rgba(26, 35, 50, 0.95) 100%)",
                border: "1px solid rgba(244, 185, 66, 0.4)",
                backdropFilter: "blur(15px)"
              }}
            >
              <h4 className="font-bold mb-4 text-sm" style={{color: "var(--warm-gold)"}}>
                風險分析矩陣
              </h4>
              
              <div className="space-y-3">
                {Object.entries(breakdown).map(([key, value]) => {
                  const percentage = Math.round((value || 0) * 10);
                  const color = percentage > 70 ? '#ff4757' : percentage > 40 ? '#F4B942' : '#00D2FF';
                  
                  return (
                    <TooltipProvider key={key}>
                      <Tooltip>
                        <TooltipTrigger asChild>
                          <div className="cursor-help">
                            <div className="flex justify-between items-center mb-1">
                              <span className="text-xs capitalize" style={{color: "var(--platinum)"}}>
                                {getBreakdownLabel(key)}
                              </span>
                              <span className="text-xs font-mono" style={{color: color}}>
                                {percentage}%
                              </span>
                            </div>
                            <div className="w-full bg-black/20 rounded-full h-1.5">
                              <motion.div
                                initial={{ width: 0 }}
                                animate={{ width: `${percentage}%` }}
                                transition={{ duration: 1, delay: 0.2 }}
                                className="h-1.5 rounded-full"
                                style={{ backgroundColor: color }}
                              />
                            </div>
                          </div>
                        </TooltipTrigger>
                        <TooltipContent 
                          className="max-w-xs border-0"
                          style={{
                            background: "rgba(10, 15, 26, 0.95)",
                            border: "1px solid rgba(244, 185, 66, 0.3)"
                          }}
                        >
                          <div className="text-xs" style={{color: "var(--warm-gold)"}}>
                            {getBreakdownTooltip(key)}
                          </div>
                        </TooltipContent>
                      </Tooltip>
                    </TooltipProvider>
                  );
                })}
              </div>

              <div className="mt-4 pt-3 border-t" style={{borderColor: "rgba(192, 192, 192, 0.1)"}}>
                <div className="text-xs opacity-70" style={{color: "var(--tech-blue)"}}>
                  對您交易本質的即時量子分析
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </TooltipProvider>
  );
}