import React, { useState, useRef, useEffect } from 'react';
import { Button } from "@/components/ui/button";
import { Mic, Zap, Brain } from "lucide-react";
import { motion } from "framer-motion";
import { InvokeLLM } from "@/api/integrations";
import { toast } from "sonner";

const VoiceButler = () => {
  const [isListening, setIsListening] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const recognitionRef = useRef(null);

  useEffect(() => {
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (SpeechRecognition) {
      const recognition = new SpeechRecognition();
      recognition.lang = 'zh-TW';
      recognition.continuous = false;
      recognition.interimResults = false;

      recognition.onresult = async (event) => {
        const command = event.results[0][0].transcript.trim();
        if (command.includes("推薦投資")) {
          setIsProcessing(true);
          toast.info("正在為您生成專屬策略...", { icon: <Brain className="animate-pulse" /> });
          try {
            const result = await InvokeLLM({
              prompt: `以繁體中文，基於一位經驗豐富的菁英投資者背景，快速生成一條簡潔、有力的投資策略建議。`,
              response_json_schema: {
                type: "object",
                properties: { recommendation: { type: "string" } }
              }
            });
            toast.success("神諭策略已生成", { description: result.recommendation });
          } catch (error) {
            toast.error("生成策略時出錯", { description: "請稍後再試。" });
          } finally {
            setIsProcessing(false);
          }
        } else {
          toast.warning("無法識別指令", { description: `收到的指令：'${command}'` });
        }
      };
      
      recognition.onstart = () => setIsListening(true);
      recognition.onend = () => setIsListening(false);
      recognition.onerror = (event) => {
        toast.error("語音辨識錯誤", { description: event.error });
        setIsListening(false);
      };

      recognitionRef.current = recognition;
    }
  }, []);

  const handleListen = () => {
    if (!recognitionRef.current) {
      toast.error("您的瀏覽器不支援語音辨識。");
      return;
    }
    if (isListening || isProcessing) return;
    recognitionRef.current.start();
  };

  return (
    <motion.div whileHover={{ scale: 1.05 }} className="fixed bottom-8 right-8 z-50">
      <Button
        size="lg"
        onClick={handleListen}
        disabled={isListening || isProcessing}
        className="rounded-full w-16 h-16 shadow-lg transition-all duration-300 glow-gold"
        style={{
          background: "linear-gradient(135deg, var(--gold) 0%, var(--gold-light) 100%)",
          color: "#000"
        }}
      >
        {isListening ? (
          <motion.div animate={{ scale: [1, 1.2, 1] }} transition={{ repeat: Infinity, duration: 1 }}>
            <Mic className="w-6 h-6" />
          </motion.div>
        ) : isProcessing ? (
          <Brain className="w-6 h-6 animate-spin" />
        ) : (
          <Zap className="w-6 h-6" />
        )}
      </Button>
      <div className="text-center text-xs mt-2 font-semibold" style={{color: "var(--gold)"}}>語音管家</div>
    </motion.div>
  );
};

export default VoiceButler;