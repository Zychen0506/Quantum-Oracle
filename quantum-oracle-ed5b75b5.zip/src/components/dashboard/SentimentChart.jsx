import React from 'react';
import { AreaChart, Area, XAxis, YAxis, ResponsiveContainer, Tooltip } from 'recharts';

export default function SentimentChart({ data = [], className }) {
  const chartData = data.length > 0 ? data : [
    { date: new Date(2024, 0, 1).toISOString(), sentiment: 0.2 },
    { date: new Date(2024, 0, 2).toISOString(), sentiment: -0.1 },
    { date: new Date(2024, 0, 3).toISOString(), sentiment: 0.4 },
    { date: new Date(2024, 0, 4).toISOString(), sentiment: 0.1 },
    { date: new Date(2024, 0, 5).toISOString(), sentiment: -0.3 },
    { date: new Date(2024, 0, 6).toISOString(), sentiment: 0.3 },
    { date: new Date(2024, 0, 7).toISOString(), sentiment: 0.5 }
  ];

  return (
    <div className={`${className}`}>
      <div className="mb-6">
        <h3 className="text-lg font-medium mb-2" style={{color: "var(--silver-light)"}}>
          Sentiment Evolution
        </h3>
        <p className="text-sm opacity-60" style={{color: "var(--silver)"}}>
          Emotional patterns across your trading journey
        </p>
      </div>
      
      <div className="h-64">
        <ResponsiveContainer width="100%" height="100%">
          <AreaChart data={chartData}>
            <defs>
              <linearGradient id="sentimentGradient" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="var(--ethereal-blue)" stopOpacity={0.4}/>
                <stop offset="95%" stopColor="var(--ethereal-blue)" stopOpacity={0}/>
              </linearGradient>
            </defs>
            <XAxis 
              dataKey="date" 
              axisLine={false}
              tickLine={false}
              tick={{fill: 'var(--silver)', fontSize: 12}}
              tickFormatter={(value) => new Date(value).toLocaleDateString('en-US', {month: 'short', day: 'numeric'})}
            />
            <YAxis 
              domain={[-1, 1]}
              axisLine={false}
              tickLine={false}
              tick={{fill: 'var(--silver)', fontSize: 12}}
              tickFormatter={(value) => value > 0 ? `+${value}` : value.toString()}
            />
            <Tooltip 
              contentStyle={{
                background: 'rgba(10, 10, 10, 0.8)',
                borderColor: 'var(--obsidian-lighter)',
                color: 'var(--silver-light)'
              }}
              itemStyle={{ color: 'var(--ethereal-blue)' }}
              labelStyle={{ color: 'var(--gold)' }}
            />
            <Area
              type="monotone"
              dataKey="sentiment"
              stroke="var(--ethereal-blue)"
              fill="url(#sentimentGradient)"
              strokeWidth={2}
              dot={{ stroke: 'var(--ethereal-blue)', strokeWidth: 1, r: 3, fill: 'var(--obsidian)' }}
              activeDot={{ r: 6, fill: 'var(--gold)' }}
            />
          </AreaChart>
        </ResponsiveContainer>
      </div>
      
      <div className="flex justify-between mt-4 text-sm">
        <div className="flex items-center gap-2">
          <div className="w-3 h-3 rounded-full" style={{backgroundColor: "var(--ethereal-blue)"}}></div>
          <span style={{color: "var(--silver)"}}>Fearful / Cautious</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-3 h-3 rounded-full" style={{backgroundColor: "var(--gold)"}}></div>
          <span style={{color: "var(--silver)"}}>Greedy / Confident</span>
        </div>
      </div>
    </div>
  );
}