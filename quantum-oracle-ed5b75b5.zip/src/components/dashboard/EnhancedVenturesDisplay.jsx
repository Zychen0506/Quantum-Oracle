import React, { useState, useEffect, useCallback } from 'react';
import { VentureOpportunity } from "@/api/entities";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Sparkles, Eye, Clock, TrendingUp } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

export default function EnhancedVenturesDisplay({ newVentures, className }) {
  const [ventures, setVentures] = useState([]);
  const [loading, setLoading] = useState(true);
  const [animateNew, setAnimateNew] = useState(false);

  const loadVentures = useCallback(async () => {
    setLoading(true);
    const data = await VentureOpportunity.list("-match_score", 20);
    setVentures(data);
    setLoading(false);
  }, []);

  const processNewVentures = useCallback(async (newOppportunities) => {
    // Convert and store new ventures
    const venturePromises = newOppportunities.slice(0, 5).map(venture => 
      VentureOpportunity.create({
        title: venture.title,
        category: venture.category || 'fintech',
        minimum_investment: venture.minimum_investment || 100000,
        expected_return: venture.expected_return || 15,
        risk_level: venture.risk_level || 'medium',
        investment_horizon: venture.investment_horizon || 'medium',
        description: venture.description,
        exclusivity_level: venture.exclusivity_level || 'private',
        match_score: venture.match_score || 85,
        closing_date: venture.closing_date,
        contact_info: venture.source || "Contact via platform"
      })
    );
    
    try {
      await Promise.all(venturePromises);
      await loadVentures(); // Refresh the display
    } catch (error) {
      console.error('處理新機會時出錯:', error);
    }
  }, [loadVentures]);

  useEffect(() => {
    loadVentures();
    
    // Check for stored ventures from daily scan
    const storedVentures = localStorage.getItem('latestVentures');
    if (storedVentures) {
      const parsed = JSON.parse(storedVentures);
      if (parsed.opportunities) {
        processNewVentures(parsed.opportunities);
      }
    }
  }, [loadVentures, processNewVentures]);

  useEffect(() => {
    if (newVentures?.length > 0) {
      processNewVentures(newVentures);
      setAnimateNew(true);
      setTimeout(() => setAnimateNew(false), 3000);
    }
  }, [newVentures, processNewVentures]);
  
  const getCategoryText = (category) => {
      const texts = {
          fintech: "金融科技",
          ai_trading: "AI交易", 
          blockchain: "區塊鏈",
          defi: "去中心化金融",
          quantitative: "量化",
          real_estate: "房地產",
          private_equity: "私募股權",
          hedge_fund: "對沖基金"
      };
      return texts[category] || "其他";
  }

  const getCategoryColor = (category) => {
    const colors = {
      fintech: "blue",
      ai_trading: "purple", 
      blockchain: "green",
      defi: "indigo",
      quantitative: "yellow",
      real_estate: "orange",
      private_equity: "red",
      hedge_fund: "pink"
    };
    return colors[category] || "gray";
  };

  const getExclusivityGlow = (level) => {
    switch(level) {
      case 'ultra_exclusive':
        return 'glow-gold';
      case 'exclusive':
        return 'glow-silver';
      default:
        return '';
    }
  };
  
  const getRiskLevelText = (level) => {
      const texts = {
          low: '低',
          medium: '中',
          high: '高'
      };
      return texts[level] || '未知';
  }
  
  const getExclusivityText = (level) => {
      const texts = {
          ultra_exclusive: '極度專屬'
      };
      return texts[level];
  }

  if (loading) {
    return (
      <div className={`${className} animate-pulse`}>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {[...Array(6)].map((_, i) => (
            <div key={i} className="h-64 bg-gray-700/50 rounded-xl"></div>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className={className}>
      {/* Header with live indicator */}
      <div className="mb-8 flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold mb-2" style={{color: "var(--silver-light)"}}>
            菁英機會聖殿
          </h2>
          <p className="opacity-70" style={{color: "var(--silver)"}}>
            為具慧眼的菁英策劃的專屬機會
          </p>
        </div>
        
        {animateNew && (
          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            className="flex items-center gap-2 px-4 py-2 rounded-full"
            style={{
              background: "linear-gradient(135deg, var(--gold) 0%, var(--gold-light) 100%)",
              color: "#000"
            }}
          >
            <Sparkles className="w-4 h-4 animate-spin" />
            <span className="text-sm font-semibold">偵測到新機會</span>
          </motion.div>
        )}
      </div>

      {ventures.length === 0 ? (
        <Card className="border-0 text-center py-16" style={{background: "rgba(42, 42, 42, 0.3)", border: "1px solid rgba(192, 192, 192, 0.1)"}}>
          <CardContent>
            <motion.div
              animate={{ rotate: 360 }}
              transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
            >
              <Sparkles className="w-16 h-16 mx-auto mb-4 opacity-40" style={{color: "var(--gold)"}} />
            </motion.div>
            <h3 className="text-xl font-semibold mb-2" style={{color: "var(--silver-light)"}}>
              專屬機會正待顯現
            </h3>
            <p className="opacity-70" style={{color: "var(--silver)"}}>
              頂級投資機會將在與您的量子檔案匹配時在此顯現。
            </p>
          </CardContent>
        </Card>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          <AnimatePresence>
            {ventures.map((venture, index) => (
              <motion.div 
                key={venture.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                transition={{ delay: index * 0.1 }}
                whileHover={{ scale: 1.02 }}
                className="relative"
              >
                <Card 
                  className={`border-0 cursor-pointer transition-all duration-500 hover:glow-gold relative overflow-hidden h-full flex flex-col ${getExclusivityGlow(venture.exclusivity_level)}`}
                  style={{
                    background: "rgba(42, 42, 42, 0.3)", 
                    border: "1px solid rgba(212, 175, 55, 0.2)"
                  }}
                >
                  {/* Exclusivity indicator */}
                  {venture.exclusivity_level === 'ultra_exclusive' && (
                    <motion.div
                      animate={{ 
                        opacity: [0.5, 1, 0.5],
                        scale: [1, 1.05, 1]
                      }}
                      transition={{ 
                        duration: 2, 
                        repeat: Infinity,
                        ease: "easeInOut"
                      }}
                      className="absolute top-2 left-2 z-10 px-2 py-1 rounded-full text-xs font-bold"
                      style={{
                        background: "linear-gradient(135deg, var(--gold) 0%, var(--gold-light) 100%)",
                        color: "#000"
                      }}
                    >
                      {getExclusivityText(venture.exclusivity_level)}
                    </motion.div>
                  )}
                  
                  {/* New indicator */}
                  {animateNew && index < 3 && (
                    <motion.div
                      initial={{ opacity: 0, scale: 0 }}
                      animate={{ opacity: 1, scale: 1 }}
                      className="absolute top-2 right-2 z-10 px-2 py-1 rounded-full text-xs font-bold bg-green-500 text-white"
                    >
                      新
                    </motion.div>
                  )}

                  <CardHeader className="relative">
                    <div className="flex items-start justify-between mb-2">
                      <Badge 
                        className={`bg-${getCategoryColor(venture.category)}-500/20 text-${getCategoryColor(venture.category)}-300 border-${getCategoryColor(venture.category)}-500/30`}
                      >
                        {getCategoryText(venture.category)}
                      </Badge>
                      <div className="text-right">
                        <div className="text-lg font-bold" style={{color: "var(--gold)"}}>
                          {venture.match_score || 85}%
                        </div>
                        <div className="text-xs opacity-60">匹配度</div>
                      </div>
                    </div>
                    
                    <CardTitle className="text-lg" style={{color: "var(--silver-light)"}}>
                      {venture.title}
                    </CardTitle>
                    
                    <div className="flex items-center gap-4 text-xs opacity-70" style={{color: "var(--silver)"}}>
                      <div className="flex items-center gap-1">
                        <TrendingUp className="w-3 h-3" />
                        {venture.expected_return}% 回報率
                      </div>
                      {venture.closing_date && (
                        <div className="flex items-center gap-1">
                          <Clock className="w-3 h-3" />
                          {new Date(venture.closing_date).toLocaleDateString()}
                        </div>
                      )}
                    </div>
                  </CardHeader>

                  <CardContent className="flex-grow">
                    <p className="text-sm mb-4 opacity-80 line-clamp-3" style={{color: "var(--silver)"}}>
                      {venture.description}
                    </p>
                    
                    <div className="space-y-2">
                      <div className="flex justify-between text-xs">
                        <span style={{color: "var(--silver)"}}>最低投資額:</span>
                        <span className="font-semibold" style={{color: "var(--gold)"}}>
                          ${venture.minimum_investment?.toLocaleString()}
                        </span>
                      </div>
                      
                      <div className="flex justify-between text-xs">
                        <span style={{color: "var(--silver)"}}>風險等級:</span>
                        <span className={`font-semibold ${
                          venture.risk_level === 'low' ? 'text-green-400' :
                          venture.risk_level === 'high' ? 'text-red-400' : 'text-yellow-400'
                        }`}>
                          {getRiskLevelText(venture.risk_level)}
                        </span>
                      </div>
                    </div>
                  </CardContent>

                  <div className="p-6 pt-0">
                    <Button 
                      variant="outline" 
                      size="sm" 
                      className="w-full transition-all duration-300 hover:glow-silver"
                      style={{
                        background: "rgba(74, 144, 226, 0.1)",
                        borderColor: "var(--ethereal-blue)", 
                        color: "var(--ethereal-blue)"
                      }}
                    >
                      <Eye className="w-4 h-4 mr-2" />
                      揭示詳情
                    </Button>
                  </div>

                  {/* Holographic overlay effect */}
                  <motion.div
                    className="absolute inset-0 bg-gradient-to-r from-transparent via-white/5 to-transparent opacity-0 hover:opacity-100"
                    animate={{
                      x: ['-100%', '100%']
                    }}
                    transition={{
                      duration: 1.5,
                      repeat: Infinity,
                      repeatDelay: 3
                    }}
                  />
                </Card>
              </motion.div>
            ))}
          </AnimatePresence>
        </div>
      )}
    </div>
  );
}