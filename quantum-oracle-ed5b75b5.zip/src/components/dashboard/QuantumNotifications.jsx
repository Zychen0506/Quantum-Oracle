import React, { useState, useEffect, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { AlertTriangle, Sparkles, X, Bell, AlertOctagon } from 'lucide-react';
import { Card, CardContent } from "@/components/ui/card";

export default function QuantumNotifications({ onDismiss }) {
  const [notifications, setNotifications] = useState([]);
  const [isVisible, setIsVisible] = useState(false);

  const dismissNotification = useCallback((id) => {
    setNotifications(prev => {
      const newNotifications = prev.filter(n => n.id !== id);
      if (newNotifications.length === 0) {
        setIsVisible(false);
      }
      return newNotifications;
    });
    onDismiss?.(id);
  }, [onDismiss]);

  useEffect(() => {
    const handleNotification = (event) => {
      const notification = {
        id: Date.now(),
        timestamp: new Date(),
        ...event.detail
      };
      setNotifications(prev => [notification, ...prev.slice(0, 4)]); 
      setIsVisible(true);
      if (notification.severity !== 'extreme') {
        setTimeout(() => dismissNotification(notification.id), 8000);
      }
    };

    const handleRegret = (event) => {
        const notification = {
            id: Date.now(),
            timestamp: new Date(),
            type: 'regret',
            severity: 'warning',
            ...event.detail
        };
        setNotifications(prev => [notification, ...prev.slice(0, 4)]);
        setIsVisible(true);
        setTimeout(() => dismissNotification(notification.id), 12000);
    }

    window.addEventListener('quantumAlert', handleNotification);
    window.addEventListener('ventureMatch', handleNotification);
    window.addEventListener('regretOpportunity', handleRegret);
    
    return () => {
      window.removeEventListener('quantumAlert', handleNotification);
      window.removeEventListener('ventureMatch', handleNotification);
      window.removeEventListener('regretOpportunity', handleRegret);
    };
  }, [dismissNotification]);

  const getNotificationIcon = (type) => {
    switch (type) {
      case 'market_volatility':
        return <AlertTriangle className="w-5 h-5 text-yellow-400" />;
      case 'new_ventures':
        return <Sparkles className="w-5 h-5" style={{color: "var(--gold)"}} />;
      case 'regret':
        return <AlertOctagon className="w-5 h-5 text-orange-400" />;
      default:
        return <Bell className="w-5 h-5" style={{color: "var(--ethereal-blue)"}} />;
    }
  };

  const getNotificationColor = (type, severity) => {
    if(type === 'regret') return '#f97316'; // Orange-500 from Tailwind's default palette
    if (type === 'market_volatility') {
      switch (severity) {
        case 'extreme': return '#ff4757';
        case 'high': return '#ffa502';
        case 'medium': return 'var(--gold)';
        default: return 'var(--ethereal-blue)';
      }
    }
    return 'var(--gold)';
  };
  
  const getNotificationTitle = (type, severity) => {
      if(type === 'market_volatility'){
          return '市場警報'
      }
      if(type === 'new_ventures'){
          return '菁英機會'
      }
      if(type === 'regret'){
          return '潛在機會提醒'
      }
      return '通知'
  }

  if (notifications.length === 0) return null;

  return (
    <AnimatePresence>
      {isVisible && (
        <motion.div
          initial={{ opacity: 0, x: 300, scale: 0.8 }}
          animate={{ opacity: 1, x: 0, scale: 1 }}
          exit={{ opacity: 0, x: 300, scale: 0.8 }}
          className="fixed top-8 right-8 z-50 space-y-4 max-w-sm"
          style={{ pointerEvents: 'none' }}
        >
          {notifications.map((notification) => (
            <motion.div
              key={notification.id}
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20, scale: 0.9 }}
              style={{ pointerEvents: 'auto' }}
            >
              <Card 
                className="border-0 relative overflow-hidden shadow-2xl"
                style={{
                  background: "linear-gradient(135deg, rgba(10, 10, 10, 0.95) 0%, rgba(26, 26, 26, 0.95) 100%)",
                  border: `1px solid ${getNotificationColor(notification.type, notification.severity)}50`,
                  backdropFilter: "blur(10px)"
                }}
              >
                <motion.div
                  animate={{
                    opacity: [0.3, 0.7, 0.3]
                  }}
                  transition={{
                    duration: 2,
                    repeat: Infinity,
                    ease: "easeInOut"
                  }}
                  className="absolute inset-0 rounded-lg"
                  style={{
                    background: `linear-gradient(135deg, ${getNotificationColor(notification.type, notification.severity)}20 0%, transparent 50%)`
                  }}
                />
                
                <CardContent className="relative p-4">
                  <div className="flex items-start gap-3">
                    <motion.div
                      animate={{
                        rotate: notification.type === 'market_volatility' ? [0, 10, -10, 0] : [0, 360]
                      }}
                      transition={{
                        duration: notification.type === 'market_volatility' ? 0.5 : 2,
                        repeat: notification.type === 'market_volatility' ? 3 : Infinity,
                        ease: "easeInOut"
                      }}
                      className="mt-1"
                    >
                      {getNotificationIcon(notification.type)}
                    </motion.div>
                    
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-1">
                        <h4 
                          className="font-semibold text-sm"
                          style={{color: getNotificationColor(notification.type, notification.severity)}}
                        >
                          {getNotificationTitle(notification.type, notification.severity)}
                        </h4>
                        {notification.severity === 'extreme' && (
                          <motion.div
                            animate={{ scale: [1, 1.2, 1] }}
                            transition={{ duration: 1, repeat: Infinity }}
                            className="w-2 h-2 rounded-full bg-red-500"
                          />
                        )}
                      </div>
                      
                      <p className="text-sm leading-relaxed mb-2" style={{color: "var(--silver-light)"}}>
                        {notification.message}
                      </p>
                      
                      {notification.count && (
                        <div className="text-xs opacity-70" style={{color: "var(--gold)"}}>
                          偵測到 {notification.count} 個新機會
                        </div>
                      )}
                      
                      <div className="text-xs mt-2 opacity-50" style={{color: "var(--silver)"}}>
                        {notification.timestamp.toLocaleTimeString()}
                      </div>
                    </div>

                    <motion.button
                      whileHover={{ scale: 1.1 }}
                      whileTap={{ scale: 0.9 }}
                      onClick={() => dismissNotification(notification.id)}
                      className="text-gray-400 hover:text-white transition-colors duration-200 p-1 rounded"
                    >
                      <X className="w-4 h-4" />
                    </motion.button>
                  </div>
                  
                  {notification.severity !== 'extreme' && (
                    <motion.div
                      initial={{ width: "100%" }}
                      animate={{ width: "0%" }}
                      transition={{ duration: notification.type === 'regret' ? 12 : 8, ease: "linear" }}
                      className="absolute bottom-0 left-0 h-0.5 rounded-full"
                      style={{background: getNotificationColor(notification.type, notification.severity)}}
                    />
                  )}
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </motion.div>
      )}
    </AnimatePresence>
  );
}