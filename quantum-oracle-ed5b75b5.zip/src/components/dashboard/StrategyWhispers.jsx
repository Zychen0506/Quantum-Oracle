import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Sparkles, Volume2 } from 'lucide-react';
import { Card, CardContent } from "@/components/ui/card";

export default function StrategyWhispers({ whisper, className }) {
  const [showWhisper, setShowWhisper] = useState(false);
  const [currentWhisper, setCurrentWhisper] = useState('');

  useEffect(() => {
    if (whisper) {
      setCurrentWhisper(whisper);
      setShowWhisper(true);
      
      // Auto-hide after 8 seconds
      const timeout = setTimeout(() => {
        setShowWhisper(false);
      }, 8000);
      
      return () => clearTimeout(timeout);
    }
  }, [whisper]);

  if (!currentWhisper) return null;

  return (
    <AnimatePresence>
      {showWhisper && (
        <motion.div
          initial={{ opacity: 0, y: 20, scale: 0.9 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          exit={{ opacity: 0, y: -20, scale: 0.9 }}
          className={`${className} relative`}
        >
          <Card 
            className="border-0 relative overflow-hidden"
            style={{
              background: "linear-gradient(135deg, rgba(212, 175, 55, 0.1) 0%, rgba(74, 144, 226, 0.1) 100%)",
              border: "1px solid rgba(212, 175, 55, 0.3)"
            }}
          >
            {/* Animated background glow */}
            <motion.div
              animate={{
                opacity: [0.3, 0.6, 0.3],
                scale: [1, 1.02, 1]
              }}
              transition={{
                duration: 3,
                repeat: Infinity,
                ease: "easeInOut"
              }}
              className="absolute inset-0 rounded-lg"
              style={{
                background: "radial-gradient(circle at center, rgba(212, 175, 55, 0.1) 0%, transparent 70%)"
              }}
            />
            
            <CardContent className="relative p-6">
              <div className="flex items-start gap-3">
                <motion.div
                  animate={{ rotate: 360 }}
                  transition={{ duration: 8, repeat: Infinity, ease: "linear" }}
                  className="mt-1"
                >
                  <Sparkles className="w-5 h-5" style={{color: "var(--gold)"}} />
                </motion.div>
                
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-2">
                    <Volume2 className="w-4 h-4" style={{color: "var(--ethereal-blue)"}} />
                    <h4 className="font-semibold text-sm" style={{color: "var(--gold)"}}>
                      神諭策略低語
                    </h4>
                  </div>
                  
                  <motion.p
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    transition={{ duration: 1, delay: 0.3 }}
                    className="text-sm leading-relaxed"
                    style={{color: "var(--silver-light)"}}
                  >
                    {currentWhisper}
                  </motion.p>
                </div>

                <motion.button
                  whileHover={{ scale: 1.1 }}
                  whileTap={{ scale: 0.9 }}
                  onClick={() => setShowWhisper(false)}
                  className="text-gray-400 hover:text-white transition-colors duration-200 p-1 rounded"
                  style={{color: "var(--silver)"}}
                >
                  ×
                </motion.button>
              </div>
              
              {/* Subtle pulse animation at bottom */}
              <motion.div
                animate={{
                  width: ["0%", "100%", "0%"]
                }}
                transition={{
                  duration: 8,
                  ease: "easeInOut"
                }}
                className="absolute bottom-0 left-0 h-0.5 rounded-full"
                style={{background: "linear-gradient(90deg, transparent, var(--gold), transparent)"}}
              />
            </CardContent>
          </Card>
        </motion.div>
      )}
    </AnimatePresence>
  );
}