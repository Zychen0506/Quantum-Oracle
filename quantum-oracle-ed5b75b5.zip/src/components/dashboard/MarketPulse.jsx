import React, { useState, useEffect } from 'react';
import { TrendingUp, TrendingDown, Activity } from 'lucide-react';
import { InvokeLLM } from '@/api/integrations';

export default function MarketPulse({ className }) {
  const [marketData, setMarketData] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchMarketData();
  }, []);

  const fetchMarketData = async () => {
    try {
      setLoading(true);
      const response = await InvokeLLM({
        prompt: `Provide current forex market sentiment and key currency pair movements (EUR/USD, GBP/USD, USD/JPY, USD/CHF). Include overall market volatility and key economic drivers. Format for a high-net-worth forex trader.`,
        add_context_from_internet: true,
        response_json_schema: {
          type: "object",
          properties: {
            overall_sentiment: { type: "string", enum: ["bullish", "bearish", "neutral"] },
            volatility_level: { type: "string", enum: ["low", "medium", "high"] },
            major_pairs: {
              type: "array", items: {
                type: "object", properties: {
                  pair: { type: "string" },
                  current_price: { type: "string" },
                  change_percent: { type: "number" },
                  trend: { type: "string", enum: ["up", "down", "sideways"] }
                }
              }
            },
            risk_assessment: { type: "string" }
          }
        }
      });
      setMarketData(response);
    } catch (error) {
      console.error('Error fetching market data:', error);
      setMarketData({
        overall_sentiment: "neutral", volatility_level: "medium", major_pairs: [
          { pair: "EUR/USD", current_price: "1.0845", change_percent: 0.12, trend: "up" },
          { pair: "GBP/USD", current_price: "1.2756", change_percent: -0.08, trend: "down" },
          { pair: "USD/JPY", current_price: "149.23", change_percent: 0.25, trend: "up" }
        ], risk_assessment: "Moderate risk with selective opportunities."
      });
    }
    setLoading(false);
  };

  if (loading) return <div className={`${className} animate-pulse`}><div className="h-64 bg-gray-700/50 rounded-xl"></div></div>;

  const getSentimentIcon = (sentiment) => {
    switch(sentiment) {
      case 'bullish': return <TrendingUp className="w-5 h-5 text-green-400" />;
      case 'bearish': return <TrendingDown className="w-5 h-5 text-red-400" />;
      default: return <Activity className="w-5 h-5 text-gold" />;
    }
  };

  return (
    <div className={`${className}`}>
      <div className="mb-6">
        <div className="flex items-center gap-3 mb-2">
          {getSentimentIcon(marketData.overall_sentiment)}
          <h3 className="text-lg font-medium" style={{color: "var(--silver-light)"}}>Market Pulse</h3>
        </div>
        <p className="text-sm opacity-60" style={{color: "var(--silver)"}}>{marketData.risk_assessment}</p>
      </div>
      <div className="space-y-4">
        {marketData.major_pairs?.map((pair) => (
          <div key={pair.pair} className="p-4 rounded-xl transition-all duration-300 hover:glow-silver border" style={{ background: "rgba(42, 42, 42, 0.3)", border: "1px solid rgba(192, 192, 192, 0.1)" }}>
            <div className="flex justify-between items-center">
              <span className="font-semibold" style={{color: "var(--silver-light)"}}>{pair.pair}</span>
              <div className="text-right">
                <div className="font-mono text-sm" style={{color: "var(--gold)"}}>{pair.current_price}</div>
                <div className={`text-xs ${pair.change_percent >= 0 ? 'text-green-400' : 'text-red-400'}`}>{pair.change_percent >= 0 ? '+' : ''}{pair.change_percent}%</div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}