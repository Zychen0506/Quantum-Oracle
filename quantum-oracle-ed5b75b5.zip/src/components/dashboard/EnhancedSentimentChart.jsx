import React, { useState, useEffect } from 'react';
import { AreaChart, Area, XAxis, YAxis, ResponsiveContainer, Tooltip } from 'recharts';
import { motion } from 'framer-motion';
import { Tooltip as ShadcnTooltip, TooltipContent, TooltipTrigger, TooltipProvider } from "@/components/ui/tooltip";
import { TrendingUp, TrendingDown, Activity } from 'lucide-react';

export default function EnhancedSentimentChart({ data = [], simulationData = null, className }) {
  const [chartData, setChartData] = useState([]);
  const [showSimulation, setShowSimulation] = useState(false);

  useEffect(() => {
    const baseData = data.length > 0 ? data : [
      { date: new Date(Date.now() - 6 * 24 * 60 * 60 * 1000).toISOString(), sentiment: 0.2 },
      { date: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000).toISOString(), sentiment: -0.1 },
      { date: new Date(Date.now() - 4 * 24 * 60 * 60 * 1000).toISOString(), sentiment: 0.4 },
      { date: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000).toISOString(), sentiment: 0.1 },
      { date: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString(), sentiment: -0.3 },
      { date: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000).toISOString(), sentiment: 0.3 },
      { date: new Date().toISOString(), sentiment: 0.5 }
    ];

    let newData = [...baseData];
    
    if (simulationData) {
      // Add simulation point
      const simPoint = {
        date: simulationData.timestamp,
        sentiment: simulationData.sentiment_score,
        isSimulation: true
      };
      newData.push(simPoint);
      newData.sort((a, b) => new Date(a.date) - new Date(b.date));
      
      setShowSimulation(true);
      setTimeout(() => setShowSimulation(false), 3000);
    }

    setChartData(newData);
  }, [data, simulationData]);

  const currentSentiment = chartData.length > 0 ? chartData[chartData.length - 1]?.sentiment : 0;
  const trend = chartData.length > 1 ? 
    chartData[chartData.length - 1]?.sentiment - chartData[chartData.length - 2]?.sentiment : 0;

  const getSentimentIcon = () => {
    if (trend > 0.1) return <TrendingUp className="w-4 h-4 text-green-400" />;
    if (trend < -0.1) return <TrendingDown className="w-4 h-4 text-red-400" />;
    return <Activity className="w-4 h-4" style={{color: "var(--warm-gold)"}} />;
  };

  return (
    <TooltipProvider>
      <div className={`${className}`}>
        <div className="mb-6">
          <div className="flex items-center gap-3 mb-2">
            <ShadcnTooltip>
              <TooltipTrigger asChild>
                <div className="flex items-center gap-2 cursor-help">
                  {getSentimentIcon()}
                  <h3 className="text-lg font-medium" style={{color: "var(--warm-gold)"}}>
                    情緒演化
                  </h3>
                </div>
              </TooltipTrigger>
              <TooltipContent 
                className="max-w-xs border-0"
                style={{
                  background: "rgba(10, 15, 26, 0.95)",
                  border: "1px solid rgba(255, 215, 0, 0.3)"
                }}
              >
                <div className="text-xs">
                  <span style={{color: "var(--warm-gold)"}}>
                    對您交易旅程中情緒模式的即時分析。恐懼與貪婪的循環被結晶為可行的洞見。
                  </span>
                </div>
              </TooltipContent>
            </ShadcnTooltip>
          </div>
          
          <div className="flex items-center justify-between">
            <p className="text-sm opacity-60" style={{color: "var(--platinum)"}}>
              您交易本質中的情緒模式
            </p>
            <div className="text-sm font-semibold" style={{color: currentSentiment > 0 ? 'var(--tech-blue)' : 'var(--warm-gold)'}}>
              當前: {currentSentiment.toFixed(2)}
            </div>
          </div>
        </div>
        
        <div className="h-64 relative">
          {showSimulation && (
            <motion.div
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.8 }}
              className="absolute top-2 right-2 z-10 px-3 py-1 rounded-full text-xs font-medium"
              style={{
                background: "linear-gradient(135deg, var(--warm-gold) 0%, var(--gold-accent) 100%)",
                color: "var(--midnight-navy)"
              }}
            >
              模擬啟動
            </motion.div>
          )}
          
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={chartData}>
              <defs>
                <linearGradient id="sentimentGradient" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#00D2FF" stopOpacity={0.6}/>
                  <stop offset="95%" stopColor="#00D2FF" stopOpacity={0.1}/>
                </linearGradient>
                <linearGradient id="simulationGradient" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#FFD700" stopOpacity={0.8}/>
                  <stop offset="95%" stopColor="#FFD700" stopOpacity={0.2}/>
                </linearGradient>
              </defs>
              
              <XAxis 
                dataKey="date" 
                axisLine={false}
                tickLine={false}
                tick={{fill: '#E0E0E0', fontSize: 12}}
                tickFormatter={(value) => new Date(value).toLocaleDateString('zh-TW', {month: 'short', day: 'numeric'})}
              />
              <YAxis 
                domain={[-1, 1]}
                axisLine={false}
                tickLine={false}
                tick={{fill: '#E0E0E0', fontSize: 12}}
                tickFormatter={(value) => value > 0 ? `+${value}` : value.toString()}
              />
              <Tooltip 
                contentStyle={{
                  background: 'rgba(10, 15, 26, 0.95)',
                  borderColor: 'rgba(255, 215, 0, 0.4)',
                  color: '#E0E0E0',
                  borderRadius: '8px',
                  border: '1px solid rgba(255, 215, 0, 0.4)'
                }}
                itemStyle={{ color: '#00D2FF' }}
                labelStyle={{ color: '#FFD700' }}
                formatter={(value, name, props) => [
                  value.toFixed(3), 
                  props.payload.isSimulation ? '模擬' : '情緒'
                ]}
              />
              <Area
                type="monotone"
                dataKey="sentiment"
                stroke="#00D2FF"
                strokeWidth={3}
                fill="url(#sentimentGradient)"
                dot={(props) => {
                  const { payload, cx, cy } = props;
                  return (
                    <circle
                      cx={cx}
                      cy={cy}
                      r={payload.isSimulation ? 8 : 4}
                      stroke={payload.isSimulation ? '#FFD700' : '#00D2FF'}
                      strokeWidth={payload.isSimulation ? 3 : 2}
                      fill={payload.isSimulation ? '#FFD700' : '#0A0F1A'}
                      className={payload.isSimulation ? 'animate-pulse' : ''}
                    />
                  );
                }}
                activeDot={{ 
                  r: 8, 
                  fill: '#FFD700', 
                  stroke: '#FFD700', 
                  strokeWidth: 3,
                  style: { filter: 'drop-shadow(0 0 8px rgba(255, 215, 0, 0.6))' }
                }}
              />
            </AreaChart>
          </ResponsiveContainer>
        </div>
        
        <div className="flex justify-between mt-4 text-sm">
          <ShadcnTooltip>
            <TooltipTrigger asChild>
              <div className="flex items-center gap-2 cursor-help">
                <div className="w-3 h-3 rounded-full" style={{backgroundColor: "#00D2FF"}}></div>
                <span style={{color: "var(--platinum)"}}>恐懼 / 謹慎</span>
              </div>
            </TooltipTrigger>
            <TooltipContent style={{background: "rgba(10, 15, 26, 0.95)", border: "1px solid rgba(255, 215, 0, 0.3)"}}>
              <div className="text-xs" style={{color: "var(--warm-gold)"}}>
                負面情緒表示謹慎、恐懼或防禦性倉位
              </div>
            </TooltipContent>
          </ShadcnTooltip>
          
          <ShadcnTooltip>
            <TooltipTrigger asChild>
              <div className="flex items-center gap-2 cursor-help">
                <div className="w-3 h-3 rounded-full" style={{backgroundColor: "#FFD700"}}></div>
                <span style={{color: "var(--platinum)"}}>貪婪 / 自信</span>
              </div>
            </TooltipTrigger>
            <TooltipContent style={{background: "rgba(10, 15, 26, 0.95)", border: "1px solid rgba(255, 215, 0, 0.3)"}}>
              <div className="text-xs" style={{color: "var(--warm-gold)"}}>
                正面情緒反映樂觀、自信或積極性倉位
              </div>
            </TooltipContent>
          </ShadcnTooltip>
        </div>
      </div>
    </TooltipProvider>
  );
}