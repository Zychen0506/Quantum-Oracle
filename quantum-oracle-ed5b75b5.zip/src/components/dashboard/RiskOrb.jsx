import React, { useRef, useEffect, memo } from 'react';
import * as THREE from 'three';

const RiskOrb = memo(({ riskScore = 50, volatility = 0.5, className }) => {
  const mountRef = useRef(null);

  useEffect(() => {
    let mount = mountRef.current;
    if (!mount) return;

    // Scene, camera, and renderer setup
    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(75, mount.clientWidth / mount.clientHeight, 0.1, 1000);
    const renderer = new THREE.WebGLRenderer({ alpha: true, antialias: true });
    renderer.setSize(mount.clientWidth, mount.clientHeight);
    renderer.setPixelRatio(window.devicePixelRatio);
    mount.appendChild(renderer.domElement);

    // Orb setup
    const getRiskColor = (score) => {
      const t = score / 100;
      const blue = new THREE.Color(0x4a90e2);
      const gold = new THREE.Color(0xd4af37);
      const red = new THREE.Color(0xff4757);
      if (t < 0.5) return blue.lerp(gold, t * 2);
      return gold.lerp(red, (t - 0.5) * 2);
    };

    const riskColor = getRiskColor(riskScore);

    // Core orb
    const coreGeometry = new THREE.SphereGeometry(1, 64, 64);
    const coreMaterial = new THREE.MeshPhongMaterial({
      color: riskColor,
      emissive: riskColor,
      emissiveIntensity: 0.4,
      shininess: 100,
    });
    const core = new THREE.Mesh(coreGeometry, coreMaterial);
    scene.add(core);
    
    // Outer shell (holographic)
    const shellGeometry = new THREE.SphereGeometry(1.2, 64, 64);
    const shellMaterial = new THREE.MeshBasicMaterial({
      color: riskColor,
      transparent: true,
      opacity: 0.15,
      wireframe: true
    });
    const shell = new THREE.Mesh(shellGeometry, shellMaterial);
    scene.add(shell);
    
    // Lighting
    const pointLight = new THREE.PointLight(0xffffff, 0.8);
    pointLight.position.set(5, 5, 5);
    scene.add(pointLight);
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.4);
    scene.add(ambientLight);

    camera.position.z = 3;

    let animationFrameId;
    const animate = () => {
      animationFrameId = requestAnimationFrame(animate);
      core.rotation.y += 0.003;
      shell.rotation.y -= 0.005;

      const pulse = 1 + Math.sin(Date.now() * 0.003) * volatility * 0.05;
      core.scale.setScalar(pulse);
      
      renderer.render(scene, camera);
    };
    animate();

    const handleResize = () => {
      camera.aspect = mount.clientWidth / mount.clientHeight;
      camera.updateProjectionMatrix();
      renderer.setSize(mount.clientWidth, mount.clientHeight);
    };
    window.addEventListener('resize', handleResize);

    return () => {
      window.removeEventListener('resize', handleResize);
      cancelAnimationFrame(animationFrameId);
      mount.removeChild(renderer.domElement);
      renderer.dispose();
    };
  }, [riskScore, volatility]);

  return <div ref={mountRef} className={className} style={{ width: '300px', height: '300px' }} />;
});

export default RiskOrb;