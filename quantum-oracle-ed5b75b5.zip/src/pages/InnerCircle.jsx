import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Avatar } from "@/components/ui/avatar";
import { Brain, Crown } from "lucide-react";

export default function InnerCircle() {
  const mockMessages = [
    {
      user: "神諭AI",
      avatar: <Brain className="w-6 h-6 text-midnight-navy" />,
      message: "偵測到DeFi市場出現短期套利機會，波動率預期在未來3小時內上升15%。建議關注AAVE/COMP交易對。",
      timestamp: "2分鐘前",
      isAI: true
    },
    {
      user: "菁英會員 Alpha",
      avatarLetter: "A",
      message: "收到。我的模型也顯示了類似信號，已建立初步觀察倉位。",
      timestamp: "1分鐘前",
    },
    {
      user: "菁英會員 Omega",
      avatarLetter: "Ω",
      message: "感謝神諭。Alpha，你的風險敞口如何？我正在考慮是否分配5%的流動資金。",
      timestamp: "剛剛",
    }
  ];

  return (
    <div className="min-h-screen p-4 md:p-8">
      <div className="max-w-4xl mx-auto">
        <div className="mb-8 text-center">
          <h1 className="text-3xl font-bold mb-2 flex items-center justify-center gap-3" style={{color: "var(--warm-gold)"}}>
            <Crown className="text-warm-gold" />
            菁英內部圈 (模擬)
          </h1>
          <p className="opacity-70" style={{color: "var(--platinum)"}}>
            僅限受邀成員的即時策略討論聖殿
          </p>
           <p className="text-sm mt-2 font-bold" style={{color: "var(--warm-gold)"}}>此為模擬展示版，未來將升級。</p>
        </div>

        <Card className="border-0" style={{background: "rgba(42, 42, 42, 0.3)", border: "1px solid rgba(212, 175, 55, 0.2)"}}>
          <CardHeader>
            <CardTitle style={{color: "var(--tech-blue)"}}># 核心策略討論</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-6">
              {mockMessages.map((msg, index) => (
                <div key={index} className="flex items-start gap-4">
                  <Avatar>
                    <div 
                      className="w-10 h-10 rounded-full flex items-center justify-center glow-platinum"
                      style={{background: msg.isAI ? "linear-gradient(135deg, var(--warm-gold) 0%, var(--gold-accent) 100%)" : "linear-gradient(135deg, var(--platinum) 0%, var(--platinum-light) 100%)"}}
                    >
                      {msg.avatar || <span className="text-midnight-navy font-bold">{msg.avatarLetter}</span>}
                    </div>
                  </Avatar>
                  <div className="flex-1">
                    <div className="flex items-baseline gap-2">
                      <p className="font-semibold" style={{color: msg.isAI ? "var(--warm-gold)" : "var(--platinum-light)"}}>{msg.user}</p>
                      <p className="text-xs opacity-70" style={{color: "var(--platinum)"}}>{msg.timestamp}</p>
                    </div>
                    <div className="mt-1 p-3 rounded-lg" style={{background: "rgba(10,10,10,0.4)"}}>
                      <p className="text-sm" style={{color: "var(--platinum-light)", textShadow: "0 0 5px rgba(240, 240, 240, 0.5)"}}>{msg.message}</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
            <div className="mt-8 pt-4 border-t border-platinum/20 text-center opacity-60 text-sm" style={{color: "var(--platinum)"}}>
              即時訊息已暫停 (模擬模式)
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}