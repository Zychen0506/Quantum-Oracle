import React, { useState, useEffect } from 'react';
import { User } from '@/api/entities';
import { SimulatedInvestment } from '@/api/entities';
import { Brain, FileText, Download } from 'lucide-react';
import { Button } from '@/components/ui/button';

export default function Report() {
  const [user, setUser] = useState(null);
  const [investments, setInvestments] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const [currentUser, investmentData] = await Promise.all([
          User.me(),
          SimulatedInvestment.list('-investment_date')
        ]);
        setUser(currentUser);
        setInvestments(investmentData);
      } catch (error) {
        console.error("載入報告數據時出錯:", error);
      } finally {
        setLoading(false);
      }
    };
    fetchData();
  }, []);

  const totals = React.useMemo(() => {
    const totalInvested = investments.reduce((sum, i) => sum + i.investment_amount, 0);
    const totalValue = investments.reduce((sum, i) => sum + i.current_value, 0);
    const totalReturn = totalValue - totalInvested;
    const returnPercentage = totalInvested > 0 ? (totalReturn / totalInvested) * 100 : 0;
    return { totalInvested, totalValue, totalReturn, returnPercentage };
  }, [investments]);

  if (loading) {
    return <div className="p-8 text-center" style={{color: "var(--silver)"}}>正在生成您的專屬報告...</div>;
  }

  return (
    <div className="bg-obsidian text-silver-light p-4 sm:p-8 md:p-12 font-sans">
        <style>
        {`
          @media print {
            body {
              -webkit-print-color-adjust: exact;
              print-color-adjust: exact;
            }
            .no-print {
              display: none !important;
            }
          }
        `}
        </style>
      <div className="max-w-4xl mx-auto bg-obsidian-light p-8 rounded-lg shadow-2xl border border-gold/20">
        <header className="flex justify-between items-start pb-6 border-b border-gold/20">
          <div>
            <h1 className="text-3xl font-bold text-gold">量子財富俱樂部</h1>
            <p className="text-silver">模擬投資績效報告</p>
          </div>
          <div className="text-right">
            <p className="font-semibold text-silver-light">{user?.full_name || '菁英會員'}</p>
            <p className="text-sm text-silver">{new Date().toLocaleDateString('zh-TW')}</p>
          </div>
        </header>

        <section className="my-8">
          <h2 className="text-xl font-semibold text-ethereal-blue mb-4">投資組合總覽 (模擬)</h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 text-center">
            <div>
              <p className="text-2xl font-bold text-silver-light">NT${totals.totalInvested.toLocaleString()}</p>
              <p className="text-sm text-silver">總投入資本</p>
            </div>
            <div>
              <p className="text-2xl font-bold text-silver-light">NT${totals.totalValue.toLocaleString()}</p>
              <p className="text-sm text-silver">當前總價值</p>
            </div>
            <div>
              <p className={`text-2xl font-bold ${totals.totalReturn >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                NT${totals.totalReturn.toLocaleString()}
              </p>
              <p className="text-sm text-silver">總收益</p>
            </div>
            <div>
              <p className={`text-2xl font-bold ${totals.returnPercentage >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                {totals.returnPercentage.toFixed(2)}%
              </p>
              <p className="text-sm text-silver">回報率</p>
            </div>
          </div>
        </section>

        <section className="my-8">
          <h2 className="text-xl font-semibold text-ethereal-blue mb-4">模擬持倉詳情</h2>
          <div className="space-y-4">
            {investments.map(inv => (
              <div key={inv.id} className="bg-obsidian p-4 rounded-md border border-silver/10">
                <h3 className="font-semibold text-gold">{inv.project_name}</h3>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-2 text-sm mt-2">
                  <p><span className="text-silver">投入:</span> NT${inv.investment_amount.toLocaleString()}</p>
                  <p><span className="text-silver">現值:</span> NT${inv.current_value.toLocaleString()}</p>
                  <p><span className="text-silver">回報率:</span> {(((inv.current_value - inv.investment_amount) / inv.investment_amount) * 100).toFixed(2)}%</p>
                  <p><span className="text-silver">狀態:</span> {inv.status}</p>
                </div>
              </div>
            ))}
          </div>
        </section>
        
        <footer className="mt-8 pt-6 border-t border-gold/20 text-center text-xs text-silver/60">
          <p>此報告由量子財富俱樂部AI生成，所有數據均為模擬，不構成真實投資建議。</p>
          <p className="font-bold mt-1">此為模擬展示版，未來將升級。</p>
        </footer>

        <div className="no-print mt-8 text-center">
            <Button onClick={() => window.print()} className="glow-silver">
                <Download className="w-4 h-4 mr-2" />
                下載或列印報告
            </Button>
        </div>
      </div>
    </div>
  );
}