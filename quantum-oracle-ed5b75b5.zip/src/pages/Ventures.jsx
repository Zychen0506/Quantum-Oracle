import React, { useState, useEffect } from "react";
import { VentureOpportunity } from "@/api/entities";
import EnhancedVenturesDisplay from "../components/dashboard/EnhancedVenturesDisplay";

export default function Ventures() {
  const [newVentures, setNewVentures] = useState([]);

  useEffect(() => {
    // Listen for venture match events
    const handleVentureMatch = (event) => {
      if (event.detail.ventures) {
        setNewVentures(event.detail.ventures);
      }
    };

    window.addEventListener('ventureMatch', handleVentureMatch);
    return () => window.removeEventListener('ventureMatch', handleVentureMatch);
  }, []);

  return (
    <div className="min-h-screen p-4 md:p-8">
      <div className="max-w-7xl mx-auto">
        <EnhancedVenturesDisplay 
          newVentures={newVentures} 
          className="w-full"
        />
      </div>
    </div>
  );
}