import Layout from "./Layout.jsx";

import Dashboard from "./Dashboard";

import Journal from "./Journal";

import Ventures from "./Ventures";

import Strategy from "./Strategy";

import Profile from "./Profile";

import EliteClub from "./EliteClub";

import InvestmentDashboard from "./InvestmentDashboard";

import ProjectMarketplace from "./ProjectMarketplace";

import Report from "./Report";

import InnerCircle from "./InnerCircle";

import { BrowserRouter as Router, Route, Routes, useLocation } from 'react-router-dom';

const PAGES = {
    
    Dashboard: Dashboard,
    
    Journal: Journal,
    
    Ventures: Ventures,
    
    Strategy: Strategy,
    
    Profile: Profile,
    
    EliteClub: EliteClub,
    
    InvestmentDashboard: InvestmentDashboard,
    
    ProjectMarketplace: ProjectMarketplace,
    
    Report: Report,
    
    InnerCircle: InnerCircle,
    
}

function _getCurrentPage(url) {
    if (url.endsWith('/')) {
        url = url.slice(0, -1);
    }
    let urlLastPart = url.split('/').pop();
    if (urlLastPart.includes('?')) {
        urlLastPart = urlLastPart.split('?')[0];
    }

    const pageName = Object.keys(PAGES).find(page => page.toLowerCase() === urlLastPart.toLowerCase());
    return pageName || Object.keys(PAGES)[0];
}

// Create a wrapper component that uses useLocation inside the Router context
function PagesContent() {
    const location = useLocation();
    const currentPage = _getCurrentPage(location.pathname);
    
    return (
        <Layout currentPageName={currentPage}>
            <Routes>            
                
                    <Route path="/" element={<Dashboard />} />
                
                
                <Route path="/Dashboard" element={<Dashboard />} />
                
                <Route path="/Journal" element={<Journal />} />
                
                <Route path="/Ventures" element={<Ventures />} />
                
                <Route path="/Strategy" element={<Strategy />} />
                
                <Route path="/Profile" element={<Profile />} />
                
                <Route path="/EliteClub" element={<EliteClub />} />
                
                <Route path="/InvestmentDashboard" element={<InvestmentDashboard />} />
                
                <Route path="/ProjectMarketplace" element={<ProjectMarketplace />} />
                
                <Route path="/Report" element={<Report />} />
                
                <Route path="/InnerCircle" element={<InnerCircle />} />
                
            </Routes>
        </Layout>
    );
}

export default function Pages() {
    return (
        <Router>
            <PagesContent />
        </Router>
    );
}