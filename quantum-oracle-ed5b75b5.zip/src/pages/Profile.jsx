import React, { useState, useEffect } from "react";
import { User } from "@/api/entities";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Shield, Save } from "lucide-react";

export default function Profile() {
  const [user, setUser] = useState(null);
  const [isSaving, setIsSaving] = useState(false);
  const [editingProfile, setEditingProfile] = useState({});

  useEffect(() => {
    loadProfile();
  }, []);

  const loadProfile = async () => {
    try {
      const currentUser = await User.me();
      setUser(currentUser);
      setEditingProfile(currentUser);
    } catch (error) {
      console.error('加載檔案時出錯:', error);
    }
  };

  const handleSaveProfile = async () => {
    setIsSaving(true);
    try {
      await User.updateMyUserData(editingProfile);
      setUser(prev => ({...prev, ...editingProfile}));
    } catch (error) {
      console.error('儲存檔案時出錯:', error);
    }
    setIsSaving(false);
  };

  if (!user) return <div className="p-8"><div className="animate-pulse h-96 bg-gray-700/50 rounded-xl"></div></div>;

  return (
    <div className="min-h-screen p-4 md:p-8">
      <div className="max-w-xl mx-auto">
        <div className="mb-8"><h1 className="text-3xl font-bold mb-2" style={{color: "var(--warm-gold)"}}>菁英檔案聖殿</h1><p className="opacity-70" style={{color: "var(--platinum)"}}>您的量子身份</p></div>
        <Card className="border-0" style={{background: "rgba(42, 42, 42, 0.3)", border: "1px solid rgba(212, 175, 55, 0.2)"}}>
          <CardHeader><CardTitle className="flex items-center gap-2" style={{color: "var(--warm-gold)"}}><Shield className="w-5 h-5" />個人資訊</CardTitle></CardHeader>
          <CardContent className="space-y-4">
            <div><Label htmlFor="full_name" style={{color: "var(--platinum-light)"}}>全名</Label><Input id="full_name" value={editingProfile.full_name || ''} onChange={(e) => setEditingProfile(prev => ({...prev, full_name: e.target.value}))} className="bg-black/20 border-gray-600 text-white" /></div>
            <div><Label htmlFor="email" style={{color: "var(--platinum-light)"}}>電子郵件</Label><Input id="email" value={user.email || ''} disabled className="bg-black/20 border-gray-600 text-white opacity-60" /></div>
            <Button onClick={handleSaveProfile} disabled={isSaving} className="w-full transition-all duration-300 glow-gold" style={{background: "linear-gradient(135deg, var(--warm-gold) 0%, var(--gold-accent) 100%)", color: "#000"}}>
              {isSaving ? <><Save className="w-4 h-4 mr-2 animate-spin" />儲存中...</> : <><Save className="w-4 h-4 mr-2" />儲存檔案</>}
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}