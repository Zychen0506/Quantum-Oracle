

import React from "react";
import { Link, useLocation } from "react-router-dom";
import { createPageUrl } from "@/utils";
import {
  LayoutDashboard,
  Target,
  BookOpen,
  Settings,
  BrainCircuit,
  Menu,
  X
} from "lucide-react";
import { User } from "@/api/entities";
import { Button } from "@/components/ui/button";
import { motion, AnimatePresence } from "framer-motion";
import PWAInstaller from "./components/pwa/PWAInstaller";
import QuickActionFAB from "./components/mobile/QuickActionFAB";

const mainTabs = [
  {
    title: "儀表板",
    icon: LayoutDashboard,
    url: createPageUrl("Dashboard"),
    description: "投資總覽"
  },
  {
    title: "投資機會",
    icon: Target,
    url: createPageUrl("ProjectMarketplace"),
    description: "專案投資"
  },
  {
    title: "交易日誌",
    icon: BookOpen,
    url: createPageUrl("Journal"),
    description: "記錄分析"
  },
  {
    title: "個人中心",
    icon: Settings,
    url: createPageUrl("Profile"),
    description: "帳戶設定"
  }
];

export default function Layout({ children, currentPageName }) {
  const location = useLocation();
  const [user, setUser] = React.useState(null);
  const [showMobileMenu, setShowMobileMenu] = React.useState(false);

  React.useEffect(() => {
    loadUser();
  }, []);

  const loadUser = async () => {
    try {
      const currentUser = await User.me();
      setUser(currentUser);
    } catch (error) {
      console.log("用戶未驗證");
    }
  };

  const handleLogout = async () => {
    await User.logout();
    window.location.href = createPageUrl("Dashboard");
  };

  const getCurrentTab = () => {
    return mainTabs.find(tab => location.pathname === tab.url) || mainTabs[0];
  };

  return (
    <>
      <style jsx global>{`
        :root {
          --midnight-navy: #0A0F1A;
          --midnight-blue: #0F1419;
          --midnight-lighter: #1A2332;
          --warm-gold: #F4B942;
          --gold-accent: #FFD700;
          --platinum: #E0E0E0;
          --platinum-light: #F0F0F0;
          --tech-blue: #4A90E2;
          --trust-green: #00C851;
        }

        * {
          -webkit-tap-highlight-color: transparent;
        }

        body {
          background: linear-gradient(135deg, var(--midnight-navy) 0%, var(--midnight-blue) 100%);
          color: var(--platinum);
          font-family: 'Noto Sans TC', 'Inter', sans-serif;
          overflow-x: hidden;
          min-height: 100vh; /* Added for dark theme coordination */
        }

        /* 確保所有頁面都有深色背景 */
        .min-h-screen {
          background: linear-gradient(135deg, var(--midnight-navy) 0%, var(--midnight-blue) 100%);
        }

        /* 移動端優化 */
        @media (max-width: 768px) {
          body {
            padding-bottom: 80px;
          }
        }

        /* 底部導航樣式 */
        .bottom-nav {
          position: fixed;
          bottom: 0;
          left: 0;
          right: 0;
          z-index: 50;
          background: linear-gradient(135deg, rgba(10, 15, 26, 0.95) 0%, rgba(26, 35, 50, 0.95) 100%);
          backdrop-filter: blur(20px);
          border-top: 1px solid rgba(244, 185, 66, 0.2);
          padding: 0.5rem 0;
          box-shadow: 0 -4px 20px rgba(0, 0, 0, 0.3);
        }

        .tab-button {
          transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
          position: relative;
        }

        .tab-button.active::before {
          content: '';
          position: absolute;
          top: -2px;
          left: 50%;
          transform: translateX(-50%);
          width: 24px;
          height: 3px;
          background: linear-gradient(90deg, var(--warm-gold), var(--gold-accent));
          border-radius: 0 0 8px 8px;
          box-shadow: 0 0 12px rgba(255, 215, 0, 0.6);
        }

        /* 折疊動畫 */
        .accordion-enter {
          opacity: 0;
          max-height: 0;
        }

        .accordion-enter-active {
          opacity: 1;
          max-height: 500px;
          transition: opacity 300ms, max-height 300ms;
        }

        .accordion-exit {
          opacity: 1;
          max-height: 500px;
        }

        .accordion-exit-active {
          opacity: 0;
          max-height: 0;
          transition: opacity 300ms, max-height 300ms;
        }
      `}</style>

      <div className="min-h-screen bg-gradient-to-br from-midnight-navy to-midnight-blue">
        {/* 桌面版頂部導航 */}
        <div className="hidden md:flex items-center justify-between p-4 border-b border-midnight-lighter bg-midnight-navy/80 backdrop-blur-lg">
          <div className="flex items-center gap-4">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-warm-gold to-gold-accent flex items-center justify-center">
              <BrainCircuit className="w-6 h-6 text-midnight-navy" />
            </div>
            <div>
              <h1 className="font-bold text-lg text-warm-gold">量子智匯平台</h1>
              <p className="text-xs text-platinum/70">QUANTUM WEALTH</p>
            </div>
          </div>

          <div className="flex items-center gap-6">
            {mainTabs.map((tab) => (
              <Link
                key={tab.title}
                to={tab.url}
                className={`px-4 py-2 rounded-lg transition-all duration-300 ${
                  location.pathname === tab.url
                    ? 'bg-warm-gold text-midnight-navy font-semibold'
                    : 'text-platinum hover:text-warm-gold'
                }`}
              >
                <div className="flex items-center gap-2">
                  <tab.icon className="w-4 h-4" />
                  <span className="hidden lg:inline">{tab.title}</span>
                </div>
              </Link>
            ))}

            {user && (
              <Button
                onClick={handleLogout}
                variant="ghost"
                className="text-platinum hover:text-warm-gold"
              >
                登出
              </Button>
            )}
          </div>
        </div>

        {/* 移動版頂部標題列 */}
        <div className="md:hidden flex items-center justify-between p-4 bg-midnight-navy/80 backdrop-blur-lg border-b border-midnight-lighter">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-warm-gold to-gold-accent flex items-center justify-center">
              <BrainCircuit className="w-5 h-5 text-midnight-navy" />
            </div>
            <div>
              <h1 className="font-bold text-warm-gold">{getCurrentTab().title}</h1>
              <p className="text-xs text-platinum/70">{getCurrentTab().description}</p>
            </div>
          </div>

          <Button
            variant="ghost"
            size="icon"
            onClick={() => setShowMobileMenu(!showMobileMenu)}
            className="text-platinum"
          >
            {showMobileMenu ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </Button>
        </div>

        {/* 移動版抽屜選單 */}
        <AnimatePresence>
          {showMobileMenu && (
            <motion.div
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="md:hidden absolute top-16 left-0 right-0 z-40 bg-midnight-navy/95 backdrop-blur-lg border-b border-midnight-lighter"
            >
              <div className="p-4 space-y-2">
                {user ? (
                  <div className="flex items-center gap-3 p-3 bg-midnight-lighter/50 rounded-lg">
                    <div className="w-10 h-10 rounded-full bg-gradient-to-br from-platinum to-platinum-light flex items-center justify-center">
                      <span className="text-midnight-navy font-bold text-sm">
                        {user.full_name?.charAt(0) || user.email?.charAt(0)}
                      </span>
                    </div>
                    <div className="flex-1">
                      <p className="font-medium text-platinum">{user.full_name || "專業會員"}</p>
                      <p className="text-xs text-warm-gold">認證投資人</p>
                    </div>
                    <Button onClick={handleLogout} variant="ghost" size="sm">
                      登出
                    </Button>
                  </div>
                ) : (
                  <Button onClick={() => User.login()} className="w-full bg-gradient-to-r from-warm-gold to-gold-accent text-midnight-navy">
                    登入平台
                  </Button>
                )}

                <div className="grid grid-cols-2 gap-2 mt-4">
                  <Link to={createPageUrl("Strategy")} className="p-3 bg-midnight-lighter/30 rounded-lg text-center">
                    <BrainCircuit className="w-5 h-5 mx-auto mb-1 text-warm-gold" />
                    <p className="text-xs text-platinum">投資策略</p>
                  </Link>
                  <Link to={createPageUrl("EliteClub")} className="p-3 bg-midnight-lighter/30 rounded-lg text-center">
                    <Target className="w-5 h-5 mx-auto mb-1 text-warm-gold" />
                    <p className="text-xs text-platinum">會員等級</p>
                  </Link>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* 主要內容 */}
        <main className="min-h-screen">
          {children}
        </main>

        {/* 底部 Tab 導航（僅移動端） */}
        <div className="md:hidden bottom-nav">
          <div className="flex justify-around items-center px-2">
            {mainTabs.map((tab) => {
              const isActive = location.pathname === tab.url;
              return (
                <Link
                  key={tab.title}
                  to={tab.url}
                  onClick={() => setShowMobileMenu(false)}
                  className={`tab-button flex flex-col items-center justify-center py-2 px-3 rounded-lg min-w-0 ${
                    isActive ? 'active' : ''
                  }`}
                >
                  <tab.icon
                    className={`w-6 h-6 mb-1 transition-colors duration-300 ${
                      isActive
                        ? 'text-warm-gold'
                        : 'text-platinum/60'
                    }`}
                  />
                  <span className={`text-xs font-medium transition-colors duration-300 ${
                    isActive
                      ? 'text-warm-gold'
                      : 'text-platinum/60'
                  }`}>
                    {tab.title}
                  </span>
                </Link>
              );
            })}
          </div>
        </div>

        {/* PWA 安裝提示 */}
        <PWAInstaller />

        {/* 懸浮快捷按鈕 */}
        <QuickActionFAB />

        {/* 離線提示 */}
        <div id="offline-indicator" className="hidden fixed bottom-20 left-4 right-4 bg-warm-gold text-midnight-navy p-3 rounded-lg text-center text-sm font-medium">
          離線模式啟用 - 數據將在連線後同步
        </div>
      </div>
    </>
  );
}

