import React, { useState, useEffect, useCallback } from "react";
import { SimulatedInvestment } from "@/api/entities";
import { User } from "@/api/entities"; // Added User import
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  TrendingUp,
  DollarSign,
  PieChart,
  Activity,
  FileText
} from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Cell } from 'recharts';

export default function InvestmentDashboard() {
  const [investments, setInvestments] = useState([]);
  const [loading, setLoading] = useState(true);
  const [totalValue, setTotalValue] = useState(0);
  const [totalProfit, setTotalProfit] = useState(0);

  const loadInvestmentData = useCallback(async () => {
    setLoading(true);
    try {
      const investmentData = await SimulatedInvestment.list("-investment_date", 20);
      
      setInvestments(investmentData);
      
      const total = investmentData.reduce((sum, inv) => sum + (inv.current_value || inv.investment_amount), 0);
      const profit = investmentData.reduce((sum, inv) => sum + ((inv.current_value || inv.investment_amount) - inv.investment_amount), 0);
      
      setTotalValue(total);
      setTotalProfit(profit);
      
    } catch (error) {
      console.error('載入投資數據時出錯:', error);
    }
    setLoading(false);
  }, []);

  useEffect(() => {
    loadInvestmentData();
  }, [loadInvestmentData]);

  const getCategoryColor = (category) => {
    const colors = {
      fintech: "blue",
      ai_trading: "purple",
      blockchain: "green", 
      defi: "indigo",
      green_energy: "emerald",
      biotech: "pink"
    };
    return colors[category] || "gray";
  };

  const getStatusColor = (status) => {
    const colors = {
      active: "green",
      matured: "blue",
      early_exit: "yellow"
    };
    return colors[status] || "gray";
  };

  const getRiskColor = (risk) => {
    const colors = {
      "低風險": "green",
      "中風險": "yellow", 
      "高風險": "orange",
      "超高風險": "red"
    };
    return colors[risk] || "gray";
  };

  // 模擬數據（如果數據庫為空）
  const mockInvestments = investments.length > 0 ? investments : [
    {
      id: 1,
      project_name: "AI量化交易基金Alpha",
      category: "ai_trading",
      investment_amount: 500000,
      current_value: 562500,
      expected_return: 15,
      investment_date: "2024-01-15",
      status: "active",
      risk_level: "中風險",
      profit_sharing_schedule: [
        { date: "2024-03-15", percentage: 25, amount: 15625, status: "paid" },
        { date: "2024-06-15", percentage: 25, amount: 15625, status: "paid" },
        { date: "2024-09-15", percentage: 25, amount: 15625, status: "pending" },
        { date: "2024-12-15", percentage: 25, amount: 15625, status: "projected" }
      ]
    },
    {
      id: 2,
      project_name: "區塊鏈金融基礎設施",
      category: "blockchain",
      investment_amount: 1000000,
      current_value: 1180000,
      expected_return: 22,
      investment_date: "2024-02-01",
      status: "active", 
      risk_level: "高風險",
      profit_sharing_schedule: [
        { date: "2024-05-01", percentage: 50, amount: 90000, status: "paid" },
        { date: "2024-11-01", percentage: 50, amount: 90000, status: "pending" }
      ]
    }
  ];

  if (loading) {
    return (
      <div className="p-8 space-y-6">
        <div className="animate-pulse space-y-6">
          <div className="h-8 bg-gray-700/50 rounded w-64"></div>
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="h-96 bg-gray-700/50 rounded-xl"></div>
            <div className="h-96 bg-gray-700/50 rounded-xl"></div>
            <div className="h-96 bg-gray-700/50 rounded-xl"></div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen p-4 md:p-8">
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="mb-6 p-4 rounded-xl border-2 border-red-500/50 bg-red-500/10"
      >
        <div className="flex items-center gap-3">
          <div>
            <h3 className="font-bold text-red-300">模擬投資展示</h3>
            <p className="text-sm text-red-200 mt-1">
              所有投資數據、收益、項目均為模擬展示，不代表真實投資結果或建議。
            </p>
          </div>
        </div>
      </motion.div>

      <div className="max-w-7xl mx-auto">
        <div className="mb-8 flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold mb-2" style={{color: "var(--silver-light)"}}>
              投資聖殿儀表板
            </h1>
            <p className="opacity-70" style={{color: "var(--silver)"}}>
              您的模擬財富帝國總覽
            </p>
          </div>
          <Link to={createPageUrl("Report")}>
            <Button className="glow-silver" variant="outline">
              <FileText className="w-4 h-4 mr-2" />
              匯出模擬報告
            </Button>
          </Link>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          {[
            {
              title: "總投資價值",
              value: `NT$${(totalValue || 1680000).toLocaleString()}`,
              change: "+12.5%",
              icon: DollarSign,
              color: "var(--gold)"
            },
            {
              title: "總收益",
              value: `NT$${(totalProfit || 242500).toLocaleString()}`,
              change: "+18.2%",
              icon: TrendingUp,
              color: "green"
            },
            {
              title: "投資項目",
              value: mockInvestments.length.toString(),
              change: "活躍中",
              icon: PieChart,
              color: "var(--ethereal-blue)"
            },
            {
              title: "待分潤",
              value: "NT$105,625",
              change: "本季",
              icon: Activity,
              color: "var(--silver)"
            }
          ].map((stat, index) => (
            <motion.div
              key={stat.title}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
            >
              <Card className="border-0 transition-all duration-300 hover:glow-silver" style={{background: "rgba(42, 42, 42, 0.3)", border: "1px solid rgba(192, 192, 192, 0.1)"}}>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between mb-2">
                    <div className="text-sm opacity-70" style={{color: "var(--silver)"}}>{stat.title}</div>
                    <stat.icon className="w-5 h-5" style={{color: stat.color}} />
                  </div>
                  <div className="text-2xl font-bold" style={{color: "var(--silver-light)"}}>{stat.value}</div>
                  <div className="text-sm font-medium" style={{color: stat.color}}>{stat.change}</div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>

        <div className="grid grid-cols-1 gap-8 mb-12">
          <div>
            <h2 className="text-xl font-bold mb-6" style={{color: "var(--gold)"}}>
              我的投資組合
            </h2>
            
            <div className="space-y-6">
              {mockInvestments.map((investment, index) => (
                <motion.div
                  key={investment.id || index}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: index * 0.1 }}
                >
                  <Card className="border-0 transition-all duration-300 hover:glow-gold" style={{background: "rgba(42, 42, 42, 0.3)", border: "1px solid rgba(212, 175, 55, 0.2)"}}>
                    <CardHeader>
                      <div className="flex items-start justify-between">
                        <div>
                          <CardTitle className="text-lg mb-2" style={{color: "var(--silver-light)"}}>
                            {investment.project_name}
                          </CardTitle>
                          <div className="flex items-center gap-2">
                            <Badge className={`bg-${getCategoryColor(investment.category)}-500/20 text-${getCategoryColor(investment.category)}-300`}>
                              {investment.category}
                            </Badge>
                            <Badge className={`bg-${getRiskColor(investment.risk_level)}-500/20 text-${getRiskColor(investment.risk_level)}-300`}>
                              {investment.risk_level}
                            </Badge>
                          </div>
                        </div>
                        <Badge className={`bg-${getStatusColor(investment.status)}-500/20 text-${getStatusColor(investment.status)}-300`}>
                          {investment.status === 'active' ? '進行中' : investment.status === 'matured' ? '已到期' : '提前退出'}
                        </Badge>
                      </div>
                    </CardHeader>

                    <CardContent>
                      <div className="grid grid-cols-2 gap-4 mb-4">
                        <div>
                          <div className="text-sm opacity-70" style={{color: "var(--silver)"}}>投資金額</div>
                          <div className="font-bold" style={{color: "var(--ethereal-blue)"}}>
                            NT${investment.investment_amount.toLocaleString()}
                          </div>
                        </div>
                        <div>
                          <div className="text-sm opacity-70" style={{color: "var(--silver)"}}>當前價值</div>
                          <div className="font-bold" style={{color: "var(--gold)"}}>
                            NT${investment.current_value.toLocaleString()}
                          </div>
                        </div>
                      </div>

                      <div className="mb-4">
                        <div className="flex justify-between items-center mb-2">
                          <span className="text-sm" style={{color: "var(--silver)"}}>收益率</span>
                          <span className={`font-bold ${investment.current_value > investment.investment_amount ? 'text-green-400' : 'text-red-400'}`}>
                            {(((investment.current_value - investment.investment_amount) / investment.investment_amount) * 100).toFixed(1)}%
                          </span>
                        </div>
                        <div className="w-full bg-black/20 rounded-full h-2">
                          <div 
                            className="h-2 rounded-full bg-gradient-to-r from-ethereal-blue to-gold"
                            style={{ width: `${Math.min(((investment.current_value - investment.investment_amount) / investment.investment_amount) * 100 + 50, 100)}%` }}
                          />
                        </div>
                      </div>

                      <div className="text-sm">
                        <div className="font-medium mb-2" style={{color: "var(--silver-light)"}}>分潤時程</div>
                        <div className="space-y-2">
                          {investment.profit_sharing_schedule?.slice(0, 2).map((schedule, i) => (
                            <div key={i} className="flex justify-between items-center">
                              <span style={{color: "var(--silver)"}}>{schedule.date}</span>
                              <div className="flex items-center gap-2">
                                <span style={{color: "var(--gold)"}}>NT${schedule.amount.toLocaleString()}</span>
                                <Badge className={`text-xs ${
                                  schedule.status === 'paid' ? 'bg-green-500/20 text-green-300' :
                                  schedule.status === 'pending' ? 'bg-yellow-500/20 text-yellow-300' :
                                  'bg-gray-500/20 text-gray-300'
                                }`}>
                                  {schedule.status === 'paid' ? '已發放' : schedule.status === 'pending' ? '待發放' : '預計'}
                                </Badge>
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}