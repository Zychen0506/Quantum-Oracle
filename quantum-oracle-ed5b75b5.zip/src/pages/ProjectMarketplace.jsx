
import React, { useState, useEffect, useCallback, useMemo } from "react";
import { PartnerProject } from "@/api/entities";
import { SimulatedInvestment } from "@/api/entities";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { 
  Search, 
  Filter, 
  Star, 
  TrendingUp, 
  Clock, 
  Shield,
  AlertTriangle,
  Zap,
  Eye
} from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

export default function ProjectMarketplace() {
  const [projects, setProjects] = useState([]);
  const [filteredProjects, setFilteredProjects] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('all');
  const [tierFilter, setTierFilter] = useState('all');
  const [selectedProject, setSelectedProject] = useState(null);
  const [showInvestmentModal, setShowInvestmentModal] = useState(false);
  const [investmentAmount, setInvestmentAmount] = useState('');
  const [paymentMethod, setPaymentMethod] = useState('TWD');

  const mockProjectsData = useMemo(() => [
    {
      id: 1,
      partner_name: "AI創新實驗室",
      project_title: "智慧交易演算法基金III期",
      category: "ai_trading",
      minimum_investment: 300000,
      target_funding: 200000000,
      current_funding: 145000000,
      commission_rate: 2.5,
      project_description: "運用深度學習技術開發的新一代量化交易系統，專注於外匯和數位資產市場。預期年化報酬率20-35%。",
      launch_date: "2024-12-01",
      closing_date: "2024-12-31",
      exclusivity_tier: "elite",
      expected_return: 25,
      social_proof_count: 123
    },
    {
      id: 2,
      partner_name: "區塊鏈基金會",
      project_title: "去中心化金融基礎設施",
      category: "defi",
      minimum_investment: 500000,
      target_funding: 150000000,
      current_funding: 89000000,
      commission_rate: 3.0,
      project_description: "構建下一代DeFi協議，提供跨鏈流動性和智能合約安全審計服務。已獲頂級創投支持。",
      launch_date: "2024-11-15",
      closing_date: "2024-12-15",
      exclusivity_tier: "ultra_exclusive",
      expected_return: 30,
      social_proof_count: 245
    },
    {
      id: 3,
      partner_name: "綠色科技投資",
      project_title: "永續能源ESG投資組合",
      category: "green_energy",
      minimum_investment: 200000,
      target_funding: 100000000,
      current_funding: 72000000,
      commission_rate: 2.0,
      project_description: "專注於太陽能、風力發電和電池技術的ESG合規投資基金。符合國際永續投資標準。",
      launch_date: "2024-10-01",
      closing_date: "2024-12-30",
      exclusivity_tier: "premium",
      expected_return: 18,
      social_proof_count: 89
    },
    {
      id: 4,
      partner_name: "生技醫療創投",
      project_title: "精準醫療AI診斷平台",
      category: "biotech",
      minimum_investment: 1000000,
      target_funding: 300000000,
      current_funding: 180000000,
      commission_rate: 4.0,
      project_description: "結合AI與生物醫學的革命性診斷技術，已通過FDA初步審核，預期3年內商業化。",
      launch_date: "2024-09-01", 
      closing_date: "2024-11-30",
      exclusivity_tier: "ultra_exclusive",
      expected_return: 45,
      social_proof_count: 312
    },
    {
      id: 5,
      partner_name: "數位資產管理",
      project_title: "機構級加密貨幣基金",
      category: "blockchain",
      minimum_investment: 1500000,
      target_funding: 500000000,
      current_funding: 285000000,
      commission_rate: 3.5,
      project_description: "為機構投資者設計的多元化加密資產投資基金，採用量化策略和風險控制。",
      launch_date: "2024-08-01",
      closing_date: "2024-12-20",
      exclusivity_tier: "elite",
      expected_return: 28,
      social_proof_count: 187
    },
    {
      id: 6,
      partner_name: "金融科技加速器",
      project_title: "普惠金融區塊鏈解決方案",
      category: "fintech",
      minimum_investment: 250000,
      target_funding: 80000000,
      current_funding: 45000000,
      commission_rate: 2.5,
      project_description: "為新興市場提供區塊鏈支付和信貸服務，已在東南亞5國展開業務。",
      launch_date: "2024-07-01",
      closing_date: "2024-12-25",
      exclusivity_tier: "premium",
      expected_return: 22,
      social_proof_count: 65
    }
  ], []);

  const loadProjects = useCallback(async () => {
    setLoading(true);
    try {
      const data = await PartnerProject.list("-launch_date", 50);
      setProjects(data.length > 0 ? data : mockProjectsData);
    } catch (error) {
      console.error('載入項目時出錯:', error);
      setProjects(mockProjectsData);
    }
    setLoading(false);
  }, [mockProjectsData]);

  const filterProjects = useCallback(() => {
    let filtered = projects;

    if (searchTerm) {
      filtered = filtered.filter(project => 
        project.project_title.toLowerCase().includes(searchTerm.toLowerCase()) ||
        project.partner_name.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }

    if (categoryFilter !== 'all') {
      filtered = filtered.filter(project => project.category === categoryFilter);
    }

    if (tierFilter !== 'all') {
      filtered = filtered.filter(project => project.exclusivity_tier === tierFilter);
    }

    setFilteredProjects(filtered);
  }, [projects, searchTerm, categoryFilter, tierFilter]);

  useEffect(() => {
    loadProjects();
  }, [loadProjects]);

  useEffect(() => {
    filterProjects();
  }, [filterProjects]);

  const handleInvestment = async () => {
    if (!selectedProject || !investmentAmount) return;

    const newInvestment = {
      project_name: selectedProject.project_title,
      category: selectedProject.category,
      investment_amount: parseFloat(investmentAmount),
      currency_type: paymentMethod,
      expected_return: selectedProject.expected_return || 15,
      investment_date: new Date().toISOString(),
      maturity_date: new Date(Date.now() + 365 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
      current_value: parseFloat(investmentAmount),
      status: 'active',
      risk_level: '中風險'
    };

    try {
      await SimulatedInvestment.create(newInvestment);
      // Dispatch regret opportunity event after some delay
      setTimeout(() => {
        window.dispatchEvent(new CustomEvent('regretOpportunity', {
            detail: { message: `您已投資 ${selectedProject.project_title}。記得分散您的投資組合，避免錯過其他高潛力機會。` }
        }));
      }, 5000);
      
      setShowInvestmentModal(false);
      setSelectedProject(null);
      setInvestmentAmount('');
    } catch (error) {
      console.error('創建模擬投資時出錯:', error);
    }
  };

  const getCategoryText = (category) => {
    const texts = {
      fintech: "金融科技",
      ai_trading: "AI交易",
      blockchain: "區塊鏈", 
      defi: "去中心化金融",
      green_energy: "綠能科技",
      biotech: "生物科技"
    };
    return texts[category] || category;
  };

  const getTierText = (tier) => {
    const texts = {
      premium: "優選",
      elite: "菁英",
      ultra_exclusive: "至尊專屬"
    };
    return texts[tier] || tier;
  };

  const getCategoryColor = (category) => {
    const colors = {
      fintech: "bg-blue-500/30 text-blue-200 border border-blue-400/30",
      ai_trading: "bg-purple-500/30 text-purple-200 border border-purple-400/30",
      blockchain: "bg-green-500/30 text-green-200 border border-green-400/30",
      defi: "bg-indigo-500/30 text-indigo-200 border border-indigo-400/30", 
      green_energy: "bg-emerald-500/30 text-emerald-200 border border-emerald-400/30",
      biotech: "bg-pink-500/30 text-pink-200 border border-pink-400/30"
    };
    return colors[category] || "bg-gray-500/30 text-gray-200 border border-gray-400/30";
  };

  // getTierGlow function removed as it's no longer used for card glow effect.

  if (loading) {
    return (
      <div className="p-8 space-y-6">
        <div className="animate-pulse space-y-6">
          <div className="h-8 bg-gray-700/50 rounded w-64"></div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[...Array(6)].map((_, i) => (
              <div key={i} className="h-96 bg-gray-700/50 rounded-xl"></div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen p-4 md:p-8" style={{background: "linear-gradient(135deg, var(--midnight-navy) 0%, var(--midnight-blue) 100%)"}}>
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="mb-6 p-4 rounded-xl border-2 border-red-500/50 bg-red-500/10"
      >
        <div className="flex items-center gap-3">
          <AlertTriangle className="w-6 h-6 text-red-400" />
          <div>
            <h3 className="font-bold" style={{color: "#ff6b6b"}}>模擬投資市場</h3>
            <p className="text-sm mt-1" style={{color: "#ffa8a8"}}>
              所有項目、收益預期、合作夥伴均為展示用途，不代表真實投資機會或保證收益。
            </p>
          </div>
        </div>
      </motion.div>

      <div className="max-w-7xl mx-auto">
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2" style={{color: "var(--warm-gold)", textShadow: "0 0 10px rgba(255, 215, 0, 0.3)"}}>
            投資項目市場
          </h1>
          <p className="text-lg" style={{color: "var(--platinum)", textShadow: "0 0 5px rgba(224, 224, 224, 0.2)"}}>
            探索菁英專屬的投資機會
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4" style={{color: "var(--platinum)"}} />
            <Input
              placeholder="搜索項目或合作夥伴..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
              style={{
                background: "rgba(26, 35, 50, 0.6)",
                border: "1px solid rgba(224, 224, 224, 0.2)",
                color: "var(--platinum)"
              }}
            />
          </div>

          <Select value={categoryFilter} onValueChange={setCategoryFilter}>
            <SelectTrigger style={{background: "rgba(26, 35, 50, 0.6)", border: "1px solid rgba(224, 224, 224, 0.2)", color: "var(--platinum)"}}>
              <SelectValue placeholder="項目類別" />
            </SelectTrigger>
            <SelectContent style={{background: "var(--midnight-navy)", border: "1px solid rgba(224, 224, 224, 0.2)"}}>
              <SelectItem value="all" style={{color: "var(--platinum)"}}>所有類別</SelectItem>
              <SelectItem value="fintech" style={{color: "var(--platinum)"}}>金融科技</SelectItem>
              <SelectItem value="ai_trading" style={{color: "var(--platinum)"}}>AI交易</SelectItem>
              <SelectItem value="blockchain" style={{color: "var(--platinum)"}}>區塊鏈</SelectItem>
              <SelectItem value="defi" style={{color: "var(--platinum)"}}>去中心化金融</SelectItem>
              <SelectItem value="green_energy" style={{color: "var(--platinum)"}}>綠能科技</SelectItem>
              <SelectItem value="biotech" style={{color: "var(--platinum)"}}>生物科技</SelectItem>
            </SelectContent>
          </Select>

          <Select value={tierFilter} onValueChange={setTierFilter}>
            <SelectTrigger style={{background: "rgba(26, 35, 50, 0.6)", border: "1px solid rgba(224, 224, 224, 0.2)", color: "var(--platinum)"}}>
              <SelectValue placeholder="專屬等級" />
            </SelectTrigger>
            <SelectContent style={{background: "var(--midnight-navy)", border: "1px solid rgba(224, 224, 224, 0.2)"}}>
              <SelectItem value="all" style={{color: "var(--platinum)"}}>所有等級</SelectItem>
              <SelectItem value="premium" style={{color: "var(--platinum)"}}>優選項目</SelectItem>
              <SelectItem value="elite" style={{color: "var(--platinum)"}}>菁英專屬</SelectItem>
              <SelectItem value="ultra_exclusive" style={{color: "var(--platinum)"}}>至尊專屬</SelectItem>
            </SelectContent>
          </Select>

          <div className="flex items-center gap-2 text-sm" style={{color: "var(--platinum)"}}>
            <Filter className="w-4 h-4" />
            {filteredProjects.length} 個項目
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          <AnimatePresence>
            {filteredProjects.map((project, index) => (
              <motion.div
                key={project.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                transition={{ delay: index * 0.1 }}
                whileHover={{ scale: 1.02 }}
                className="relative"
              >
                <Card 
                  className="border-0 cursor-pointer transition-all duration-500 h-full flex flex-col"
                  style={{
                    background: "rgba(26, 35, 50, 0.8)",
                    border: "1px solid rgba(244, 185, 66, 0.3)",
                    boxShadow: project.exclusivity_tier === 'ultra_exclusive' ? "0 0 20px rgba(244, 185, 66, 0.2)" : "none"
                  }}
                >
                  {project.exclusivity_tier === 'ultra_exclusive' && (
                    <div className="absolute top-4 right-4 z-10">
                      <Badge className="font-bold px-2 py-1" style={{background: "linear-gradient(135deg, var(--warm-gold) 0%, var(--gold-accent) 100%)", color: "var(--midnight-navy)"}}>
                        <Star className="w-3 h-3 mr-1" />
                        至尊
                      </Badge>
                    </div>
                  )}

                  <CardHeader>
                    <div className="flex items-start justify-between mb-2">
                      <Badge className={getCategoryColor(project.category)}>
                        {getCategoryText(project.category)}
                      </Badge>
                      <div className="text-right">
                        <div className="text-lg font-bold" style={{color: "var(--warm-gold)", textShadow: "0 0 5px rgba(255, 215, 0, 0.3)"}}>
                          {project.expected_return || 20}%
                        </div>
                        <div className="text-xs" style={{color: "var(--platinum)"}}>預期收益</div>
                      </div>
                    </div>

                    <CardTitle className="text-lg" style={{color: "var(--platinum)", textShadow: "0 0 5px rgba(224, 224, 224, 0.2)"}}>
                      {project.project_title}
                    </CardTitle>
                    
                    <div className="text-sm" style={{color: "var(--warm-gold)"}}>
                      by {project.partner_name}
                    </div>
                  </CardHeader>

                  <CardContent className="flex-grow flex flex-col justify-between">
                    <div>
                      <p className="text-sm mb-4 line-clamp-3" style={{color: "var(--platinum)", lineHeight: "1.5"}}>
                        {project.project_description}
                      </p>
                      <div className="flex items-center gap-2 text-sm mb-4" style={{color: 'var(--tech-blue)'}}>
                          <Eye className="w-4 h-4" />
                          <span>{project.social_proof_count || Math.floor((project.id || index + 1) * 3.14)} 位菁英已關注</span>
                      </div>
                      <div className="space-y-3 mb-4">
                        <div className="flex justify-between text-sm">
                          <span style={{color: "var(--platinum)"}}>最低投資</span>
                          <span className="font-semibold" style={{color: "var(--warm-gold)"}}>
                            NT${project.minimum_investment.toLocaleString()}
                          </span>
                        </div>
                        
                        <div className="flex justify-between text-sm">
                          <span style={{color: "var(--platinum)"}}>募資進度</span>
                          <span style={{color: "var(--tech-blue)"}}>
                            {Math.round((project.current_funding / project.target_funding) * 100)}%
                          </span>
                        </div>
                        
                        <div className="w-full bg-black/30 rounded-full h-2">
                          <div 
                            className="h-2 rounded-full"
                            style={{ 
                              width: `${(project.current_funding / project.target_funding) * 100}%`,
                              background: "linear-gradient(90deg, var(--tech-blue) 0%, var(--warm-gold) 100%)"
                            }}
                          />
                        </div>

                        <div className="flex items-center gap-2 text-xs">
                          <Clock className="w-3 h-3" style={{color: "var(--platinum)"}} />
                          <span style={{color: "var(--platinum)"}}>
                            截止: {new Date(project.closing_date).toLocaleDateString()}
                          </span>
                        </div>
                      </div>
                    </div>

                    <Button
                      onClick={() => {
                        setSelectedProject(project);
                        setShowInvestmentModal(true);
                      }}
                      className="w-full transition-all duration-300 font-semibold"
                      style={{
                        background: "linear-gradient(135deg, var(--tech-blue) 0%, rgba(74, 144, 226, 0.8) 100%)",
                        color: "white",
                        border: "1px solid var(--tech-blue)",
                        textShadow: "0 0 5px rgba(255, 255, 255, 0.3)"
                      }}
                    >
                      <Zap className="w-4 h-4 mr-2" />
                      立即投資 (模擬)
                    </Button>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </AnimatePresence>
        </div>

        <AnimatePresence>
          {showInvestmentModal && selectedProject && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 z-50 flex items-center justify-center bg-black/80"
            >
              <motion.div
                initial={{ scale: 0.8, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                exit={{ scale: 0.8, opacity: 0 }}
                className="bg-obsidian-light p-8 rounded-2xl border max-w-lg w-full mx-4"
                style={{border: "1px solid var(--gold)"}}
              >
                <div className="text-center mb-6">
                  <h3 className="text-xl font-bold mb-2" style={{color: "var(--gold)"}}>
                    模擬投資
                  </h3>
                  <p className="text-sm opacity-60" style={{color: "var(--silver)"}}>
                    {selectedProject.project_title}
                  </p>
                </div>

                <div className="space-y-4 mb-6">
                  <div>
                    <label className="block text-sm font-medium mb-2" style={{color: "var(--silver-light)"}}>
                      投資金額 (NT$)
                    </label>
                    <Input
                      type="number"
                      placeholder={`最低 ${selectedProject.minimum_investment.toLocaleString()}`}
                      value={investmentAmount}
                      onChange={(e) => setInvestmentAmount(e.target.value)}
                      className="bg-black/20 border-gray-600 text-white"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium mb-2" style={{color: "var(--silver-light)"}}>
                      支付方式 (模擬)
                    </label>
                    <Select value={paymentMethod} onValueChange={setPaymentMethod}>
                      <SelectTrigger className="bg-black/20 border-gray-600 text-white">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="TWD">台幣轉帳</SelectItem>
                        <SelectItem value="USDT">USDT</SelectItem>
                        <SelectItem value="BTC">比特幣</SelectItem>
                        <SelectItem value="ETH">以太幣</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="p-4 rounded-lg border" style={{background: "rgba(42, 42, 42, 0.3)", border: "1px solid rgba(192, 192, 192, 0.1)"}}>
                    <div className="text-sm space-y-2">
                      <div className="flex justify-between">
                        <span style={{color: "var(--silver)"}}>預期年化收益:</span>
                        <span style={{color: "var(--gold)"}}>{selectedProject.expected_return || 20}%</span>
                      </div>
                      <div className="flex justify-between">
                        <span style={{color: "var(--silver)"}}>平台手續費:</span>
                        <span style={{color: "var(--ethereal-blue)"}}>{selectedProject.commission_rate}%</span>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="flex gap-3">
                  <Button
                    onClick={() => setShowInvestmentModal(false)}
                    variant="outline"
                    className="flex-1"
                  >
                    取消
                  </Button>
                  <Button
                    onClick={handleInvestment}
                    disabled={!investmentAmount || parseFloat(investmentAmount) < selectedProject.minimum_investment}
                    className="flex-1 glow-gold"
                    style={{background: "linear-gradient(135deg, var(--gold) 0%, var(--gold-light) 100%)", color: "#000"}}
                  >
                    確認投資 (模擬)
                  </Button>
                </div>

                <div className="mt-4 p-3 rounded bg-red-500/10 border border-red-500/30">
                  <p className="text-xs text-red-300 text-center">
                    ⚠️ 此為模擬投資，不涉及真實資金
                  </p>
                </div>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
