import React, { useState, useEffect } from "react";
import { User } from "@/api/entities";
import { MembershipTier } from "@/api/entities";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Crown, Shield, Zap, Star, AlertTriangle } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";

export default function EliteClub() {
  const [user, setUser] = useState(null);
  const [membershipTiers, setMembershipTiers] = useState([]);
  const [selectedTier, setSelectedTier] = useState(null);
  const [showPaymentDemo, setShowPaymentDemo] = useState(false);

  useEffect(() => {
    loadUserAndTiers();
  }, []);

  const loadUserAndTiers = async () => {
    try {
      const currentUser = await User.me();
      setUser(currentUser);
      
      const tiers = await MembershipTier.list();
      setMembershipTiers(tiers);
    } catch (error) {
      console.error('載入會員資料時出錯:', error);
    }
  };

  const handleMembershipUpgrade = (tier) => {
    setSelectedTier(tier);
    setShowPaymentDemo(true);
  };

  const simulatePayment = () => {
    // 模擬支付流程
    setTimeout(() => {
      setShowPaymentDemo(false);
      // 模擬升級會員等級
      alert('模擬支付成功！歡迎加入量子財富俱樂部菁英會員！');
    }, 2000);
  };

  const tiers = membershipTiers.length > 0 ? membershipTiers : [
    {
      tier_name: "菁英會員",
      annual_fee: 5000,
      benefits: ["專屬投資項目", "AI風險分析", "24/7 客服支援", "月度策略報告"],
      investment_minimum: 100000,
      exclusive_projects: true,
      priority_access: true
    },
    {
      tier_name: "至尊會員", 
      annual_fee: 25000,
      benefits: ["所有菁英權益", "私人投資顧問", "獨家創投機會", "優先投資權"],
      investment_minimum: 500000,
      exclusive_projects: true,
      priority_access: true
    },
    {
      tier_name: "鑽石會員",
      annual_fee: 100000,
      benefits: ["所有至尊權益", "專屬項目管道", "個人化資產配置", "直接合夥機會"],
      investment_minimum: 2000000,
      exclusive_projects: true,
      priority_access: true
    }
  ];

  return (
    <div className="min-h-screen p-4 md:p-8">
      {/* 模擬免責聲明 */}
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="mb-6 p-4 rounded-xl border-2 border-red-500/50 bg-red-500/10"
      >
        <div className="flex items-center gap-3">
          <AlertTriangle className="w-6 h-6 text-red-400" />
          <div>
            <h3 className="font-bold text-red-300">重要聲明：此為模擬展示</h3>
            <p className="text-sm text-red-200 mt-1">
              本頁面所有內容僅供展示用途，不構成真實投資建議或服務。所有數據、費用、投資項目均為虛擬模擬。
            </p>
          </div>
        </div>
      </motion.div>

      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-12">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="mb-6"
          >
            <h1 className="text-4xl font-bold mb-4" style={{color: "var(--warm-gold)"}}>
              量子財富俱樂部
            </h1>
            <p className="text-xl opacity-80" style={{color: "var(--platinum)"}}>
              邀請制菁英投資聖殿
            </p>
            <p className="text-sm mt-2 opacity-60" style={{color: "var(--platinum)"}}>
              為高淨值客戶打造的專屬財富管理體驗
            </p>
          </motion.div>
        </div>

        {/* 會員等級展示 */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-12">
          {tiers.map((tier, index) => (
            <motion.div
              key={tier.tier_name}
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.2 }}
              whileHover={{ scale: 1.02 }}
            >
              <Card 
                className={`border-0 relative overflow-hidden h-full transition-all duration-500 ${
                  index === 1 ? 'glow-gold scale-105' : 'hover:glow-platinum'
                }`}
                style={{
                  background: index === 1 
                    ? "linear-gradient(135deg, rgba(212, 175, 55, 0.1) 0%, rgba(42, 42, 42, 0.8) 100%)"
                    : "rgba(42, 42, 42, 0.5)",
                  border: `1px solid ${index === 1 ? 'var(--warm-gold)' : 'rgba(192, 192, 192, 0.2)'}`
                }}
              >
                {/* 推薦標籤 */}
                {index === 1 && (
                  <div className="absolute top-4 right-4 z-10">
                    <Badge className="bg-gold-accent text-midnight-navy font-bold px-3 py-1">
                      <Star className="w-3 h-3 mr-1" />
                      推薦
                    </Badge>
                  </div>
                )}

                <CardHeader className="text-center pb-4">
                  <div className="flex justify-center mb-4">
                    {index === 0 && <Shield className="w-12 h-12" style={{color: "var(--tech-blue)"}} />}
                    {index === 1 && <Crown className="w-12 h-12" style={{color: "var(--warm-gold)"}} />}
                    {index === 2 && <Zap className="w-12 h-12 text-purple-400" />}
                  </div>
                  
                  <CardTitle className="text-2xl mb-2" style={{color: "var(--platinum-light)"}}>
                    {tier.tier_name}
                  </CardTitle>
                  
                  <div className="text-3xl font-bold" style={{color: index === 1 ? "var(--warm-gold)" : "var(--tech-blue)"}}>
                    NT${tier.annual_fee.toLocaleString()}
                    <div className="text-sm font-normal opacity-60">/ 年</div>
                  </div>
                </CardHeader>

                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    {tier.benefits.map((benefit, i) => (
                      <div key={i} className="flex items-center gap-2 text-sm">
                        <div className="w-2 h-2 rounded-full" style={{backgroundColor: index === 1 ? "var(--warm-gold)" : "var(--tech-blue)"}}></div>
                        <span style={{color: "var(--platinum)"}}>{benefit}</span>
                      </div>
                    ))}
                  </div>

                  <div className="pt-4 border-t" style={{borderColor: "rgba(192, 192, 192, 0.1)"}}>
                    <div className="text-xs mb-4" style={{color: "var(--platinum)"}}>
                      <div>最低投資門檻：NT${tier.investment_minimum.toLocaleString()}</div>
                    </div>
                    
                    <Button
                      onClick={() => handleMembershipUpgrade(tier)}
                      className={`w-full transition-all duration-300 ${
                        index === 1 ? 'glow-gold' : 'hover:glow-platinum'
                      }`}
                      style={{
                        background: index === 1 
                          ? "linear-gradient(135deg, var(--warm-gold) 0%, var(--gold-accent) 100%)"
                          : "rgba(74, 144, 226, 0.2)",
                        color: index === 1 ? "#000" : "var(--tech-blue)",
                        border: `1px solid ${index === 1 ? 'var(--warm-gold)' : 'var(--tech-blue)'}`
                      }}
                    >
                      {index === 1 ? '立即加入' : '升級會員'}
                    </Button>
                  </div>
                </CardContent>

                {/* 全息效果 */}
                <motion.div
                  className="absolute inset-0 bg-gradient-to-r from-transparent via-white/5 to-transparent opacity-0 hover:opacity-100"
                  animate={{
                    x: ['-100%', '100%']
                  }}
                  transition={{
                    duration: 2,
                    repeat: Infinity,
                    repeatDelay: 3
                  }}
                />
              </Card>
            </motion.div>
          ))}
        </div>

        {/* 模擬支付流程 */}
        <AnimatePresence>
          {showPaymentDemo && selectedTier && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 z-50 flex items-center justify-center bg-black/80"
            >
              <motion.div
                initial={{ scale: 0.8, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                exit={{ scale: 0.8, opacity: 0 }}
                className="bg-obsidian-light p-8 rounded-2xl border max-w-md w-full mx-4"
                style={{border: "1px solid var(--warm-gold)"}}
              >
                <div className="text-center mb-6">
                  <h3 className="text-xl font-bold mb-2" style={{color: "var(--warm-gold)"}}>
                    模擬支付展示
                  </h3>
                  <p className="text-sm opacity-60" style={{color: "var(--platinum)"}}>
                    {selectedTier.tier_name} - NT${selectedTier.annual_fee.toLocaleString()}
                  </p>
                </div>

                <div className="space-y-4 mb-6">
                  <div className="p-4 rounded-lg border" style={{background: "rgba(42, 42, 42, 0.3)", border: "1px solid rgba(192, 192, 192, 0.1)"}}>
                    <div className="text-sm font-medium mb-2" style={{color: "var(--platinum-light)"}}>
                      支付方式選擇（模擬）
                    </div>
                    <div className="grid grid-cols-2 gap-2">
                      {['台幣轉帳', 'USDT', 'BTC', 'ETH'].map(method => (
                        <button key={method} className="p-2 rounded border text-xs hover:glow-platinum transition-all" style={{border: "1px solid rgba(192, 192, 192, 0.2)", color: "var(--platinum)"}}>
                          {method}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>

                <div className="flex gap-3">
                  <Button
                    onClick={() => setShowPaymentDemo(false)}
                    variant="outline"
                    className="flex-1"
                  >
                    取消
                  </Button>
                  <Button
                    onClick={simulatePayment}
                    className="flex-1 glow-gold"
                    style={{background: "linear-gradient(135deg, var(--warm-gold) 0%, var(--gold-accent) 100%)", color: "#000"}}
                  >
                    模擬支付
                  </Button>
                </div>

                <div className="mt-4 p-3 rounded bg-red-500/10 border border-red-500/30">
                  <p className="text-xs text-red-300 text-center">
                    ⚠️ 此為展示用途，不會進行真實扣款
                  </p>
                </div>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* 進入投資儀表板 */}
        <div className="text-center">
          <Link to={createPageUrl("InvestmentDashboard")}>
            <Button 
              size="lg"
              className="glow-gold px-8 py-4 text-lg"
              style={{background: "linear-gradient(135deg, var(--warm-gold) 0%, var(--gold-accent) 100%)", color: "#000"}}
            >
              <Crown className="w-5 h-5 mr-2" />
              進入投資聖殿
            </Button>
          </Link>
        </div>
      </div>
    </div>
  );
}