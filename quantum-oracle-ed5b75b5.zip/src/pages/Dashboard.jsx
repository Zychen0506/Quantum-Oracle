
import React, { useState, useEffect } from "react";
import { TradingJournal, RiskProfile } from "@/api/entities";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Brain, Target, TrendingUp, Shield, Zap, TestTube, ChevronDown, ChevronUp, BarChart3, Eye, EyeOff } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";

// Enhanced components with real-time capabilities
import EnhancedRiskOrb from "../components/dashboard/EnhancedRiskOrb";
import EnhancedSentimentChart from "../components/dashboard/EnhancedSentimentChart";
import EnhancedMarketPulse from "../components/dashboard/EnhancedMarketPulse";
import SimulationPanel from "../components/dashboard/SimulationPanel";
import QuantumNotifications from "../components/dashboard/QuantumNotifications";
import MarketVigilance from "../components/services/MarketVigilance";
import MobileDashboardCard from "../components/mobile/MobileDashboardCard";
import EmotionalInsights from "../components/dashboard/EmotionalInsights";

export default function Dashboard() {
  const [journals, setJournals] = useState([]);
  const [riskProfile, setRiskProfile] = useState(null);
  const [loading, setLoading] = useState(true);
  const [simulationMode, setSimulationMode] = useState(false);
  const [currentSimulation, setCurrentSimulation] = useState(null);
  const [marketData, setMarketData] = useState(null);
  const [marketAlerts, setMarketAlerts] = useState([]);
  
  // 移動端狀態控制
  const [expandedSections, setExpandedSections] = useState({
    risk: false,
    emotion: false,
    market: false,
    insights: false
  });
  const [showOverview, setShowOverview] = useState(false);
  const [isMobile, setIsMobile] = useState(false);

  useEffect(() => {
    loadDashboardData();
    checkMobile();
    
    // 監聽螢幕大小變化
    const handleResize = () => checkMobile();
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  const checkMobile = () => {
    setIsMobile(window.innerWidth < 768);
  };

  const loadDashboardData = async () => {
    setLoading(true);
    try {
      const [journalData, riskData] = await Promise.all([
        TradingJournal.list("-entry_date", 30),
        RiskProfile.list("-profile_date", 1)
      ]);
      setJournals(journalData);
      setRiskProfile(riskData[0] || null);
    } catch (error) {
      console.error('載入數據時出錯:', error);
    }
    setLoading(false);
  };

  const handleSimulationResult = (simulation) => {
    setCurrentSimulation(simulation);
  };

  const handleMarketUpdate = (data) => {
    setMarketData(data);
  };

  const handleRiskAlert = (alert) => {
    setMarketAlerts(prev => [alert, ...prev.slice(0, 4)]);
    
    // 情緒推送提醒
    if (alert.type === 'market_volatility') {
      setTimeout(() => {
        window.dispatchEvent(new CustomEvent('emotionalAlert', {
          detail: {
            type: 'greed_warning',
            message: '檢測到市場波動加劇，您的貪婪指數可能上升，建議重新審視投資組合配置。',
            severity: alert.severity
          }
        }));
      }, 2000);
    }
  };

  const handleVentureMatch = (match) => {
    window.dispatchEvent(new CustomEvent('ventureMatch', {
      detail: match
    }));
  };
  
  const toggleSection = (section) => {
    setExpandedSections(prev => ({
      ...prev,
      [section]: !prev[section]
    }));
  };

  const stats = React.useMemo(() => {
    if (journals.length === 0) return { avgSentiment: 0, totalTrades: 0, winRate: 0, totalProfitLoss: 0 };
    
    const avgSentiment = journals.reduce((sum, j) => sum + (j.sentiment_score || 0), 0) / journals.length;
    const profitableTrades = journals.filter(j => (j.profit_loss || 0) > 0).length;
    const winRate = (profitableTrades / journals.length) * 100;
    const totalProfitLoss = journals.reduce((sum, j) => sum + (j.profit_loss || 0), 0);
    
    return { avgSentiment, totalTrades: journals.length, winRate, totalProfitLoss };
  }, [journals]);

  const enhancedStats = React.useMemo(() => {
    let adjustedSentiment = stats.avgSentiment;
    let adjustedRiskScore = riskProfile?.overall_risk_score || 50;
    let riskBreakdown = {};

    if (currentSimulation) {
      adjustedSentiment = (adjustedSentiment + currentSimulation.sentiment_score) / 2;
      adjustedRiskScore = Math.max(0, Math.min(100, adjustedRiskScore + currentSimulation.risk_impact));
      riskBreakdown = currentSimulation.risk_breakdown || {};
    }

    if (marketData) {
      const marketImpact = marketData.volatility_index * 10;
      adjustedRiskScore = Math.max(0, Math.min(100, adjustedRiskScore + marketImpact));
    }

    return { 
      ...stats, 
      avgSentiment: adjustedSentiment, 
      riskScore: adjustedRiskScore,
      riskBreakdown
    };
  }, [stats, riskProfile, currentSimulation, marketData]);

  if (loading) {
    return (
      <div className="p-4 md:p-8 space-y-6">
        <div className="animate-pulse space-y-6">
          <div className="h-8 bg-gray-700/50 rounded w-64"></div>
          <div className="grid grid-cols-1 gap-4">
            {[...Array(4)].map((_, i) => (
              <div key={i} className="h-24 bg-gray-700/50 rounded-xl"></div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  // 核心指標卡片配置
  const coreMetrics = [
    {
      id: 'risk',
      title: "智能風險評級",
      value: enhancedStats.riskScore.toFixed(0),
      subtitle: enhancedStats.riskScore < 30 ? '保守型' : enhancedStats.riskScore < 70 ? '穩健型' : '積極型',
      icon: Brain,
      color: 'var(--warm-gold)',
      change: currentSimulation ? '+即時更新' : null,
      expandable: true
    },
    {
      id: 'emotion',
      title: "情緒智能指數", 
      value: enhancedStats.avgSentiment.toFixed(2),
      subtitle: enhancedStats.avgSentiment > 0.1 ? '樂觀' : enhancedStats.avgSentiment < -0.1 ? '謹慎' : '中性',
      icon: Target,
      color: 'var(--tech-blue)',
      change: enhancedStats.avgSentiment >= 0 ? '+積極' : '-謹慎',
      expandable: true
    },
    {
      id: 'performance',
      title: "投資勝率",
      value: `${stats.winRate.toFixed(0)}%`,
      subtitle: stats.totalTrades > 0 ? `${stats.totalTrades} 筆交易` : '尚無數據',
      icon: TrendingUp,
      color: 'var(--trust-green)',
      change: stats.winRate >= 60 ? '+優秀' : stats.winRate >= 40 ? '正常' : '-需改進'
    },
    {
      id: 'profit',
      title: "總損益",
      value: `$${stats.totalProfitLoss.toFixed(0)}`,
      subtitle: stats.totalProfitLoss >= 0 ? '獲利中' : '虧損中',
      icon: Shield,
      color: stats.totalProfitLoss >= 0 ? 'var(--trust-green)' : '#ff6b6b',
      change: stats.totalProfitLoss >= 0 ? '+獲利' : '-虧損'
    }
  ];

  return (
    <>
      <MarketVigilance 
        onMarketUpdate={handleMarketUpdate}
        onRiskAlert={handleRiskAlert}
        onVentureMatch={handleVentureMatch}
        onError={() => {}}
      />
      
      <QuantumNotifications />
      <EmotionalInsights />
      
      <div className="min-h-screen p-4 md:p-8">
        <div className="max-w-7xl mx-auto">
          {/* 頂部標題區域 */}
          <div className="mb-6 flex flex-col md:flex-row md:items-center md:justify-between gap-4">
            <div>
              <h1 className="text-2xl md:text-3xl font-bold text-warm-gold">
                智匯投資儀表板
              </h1>
              <p className="text-sm md:text-base text-platinum/70 mt-1">
                您的專屬財富管理助理
              </p>
            </div>
            
            <div className="flex gap-2 md:gap-3">
              {isMobile && (
                <Button
                  onClick={() => setShowOverview(!showOverview)}
                  variant="outline"
                  size="sm"
                  className="flex-1 md:flex-none bg-midnight-lighter/50 border-warm-gold/30 text-warm-gold"
                >
                  {showOverview ? <EyeOff className="w-4 h-4 mr-2" /> : <Eye className="w-4 h-4 mr-2" />}
                  {showOverview ? '簡化檢視' : '完整總覽'}
                </Button>
              )}
              
              <Button
                onClick={() => setSimulationMode(!simulationMode)}
                variant={simulationMode ? "default" : "outline"}
                size="sm"
                className={`transition-all duration-300 ${
                  simulationMode 
                    ? 'bg-gradient-to-r from-warm-gold to-gold-accent text-midnight-navy' 
                    : 'bg-midnight-lighter/50 border-warm-gold/30 text-warm-gold'
                }`}
              >
                <TestTube className="w-4 h-4 mr-2" />
                {isMobile ? '模擬' : '模擬測試'}
              </Button>
            </div>
          </div>

          {/* 核心指標卡片 */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 md:gap-6 mb-6 md:mb-8">
            {coreMetrics.map((metric) => (
              <MobileDashboardCard
                key={metric.id}
                metric={metric}
                onToggle={() => toggleSection(metric.id)}
                isExpanded={expandedSections[metric.id]}
                isMobile={isMobile}
                showOverview={showOverview}
              />
            ))}
          </div>

          {/* 模擬面板 */}
          <AnimatePresence>
            {simulationMode && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: "auto" }}
                exit={{ opacity: 0, height: 0 }}
                className="mb-6 md:mb-8"
              >
                <SimulationPanel onSimulationResult={handleSimulationResult} />
              </motion.div>
            )}
          </AnimatePresence>

          {/* 詳細分析區域 */}
          {(showOverview || !isMobile) && (
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 md:gap-6">
              {/* 風險分析 */}
              <Collapsible 
                open={expandedSections.risk || !isMobile}
                onOpenChange={() => toggleSection('risk')}
              >
                <Card className="border-0 bg-midnight-lighter/40 border-warm-gold/20">
                  <CardHeader className="pb-4">
                    <CollapsibleTrigger className="flex items-center justify-between w-full md:cursor-default">
                      <CardTitle className="text-lg font-medium text-warm-gold">風險分析模型</CardTitle>
                      {isMobile && <ChevronDown className="w-5 h-5 text-warm-gold transition-transform data-[state=open]:rotate-180" />}
                    </CollapsibleTrigger>
                  </CardHeader>
                  <CollapsibleContent>
                    <CardContent className="flex flex-col items-center justify-center pt-0">
                      <div className="w-full max-w-xs">
                        <EnhancedRiskOrb 
                          riskScore={enhancedStats.riskScore}
                          volatility={marketData?.volatility_index || 0.5}
                          riskBreakdown={enhancedStats.riskBreakdown}
                          isSimulating={!!currentSimulation}
                        />
                      </div>
                    </CardContent>
                  </CollapsibleContent>
                </Card>
              </Collapsible>

              {/* 情緒分析 */}
              <Card className="border-0 bg-midnight-lighter/40 border-tech-blue/20">
                <CardContent className="p-4 md:p-6">
                  <EnhancedSentimentChart 
                    data={journals.map(j => ({ date: j.entry_date, sentiment: j.sentiment_score || 0 }))} 
                    simulationData={currentSimulation}
                  />
                </CardContent>
              </Card>

              {/* 市場脈動 */}
              <Card className="border-0 bg-midnight-lighter/40 border-platinum/20">
                <CardContent className="p-4 md:p-6">
                  <EnhancedMarketPulse marketData={marketData} />
                </CardContent>
              </Card>
            </div>
          )}

          {/* 快速動作提示 */}
          {isMobile && (
            <div className="mt-8 mb-20 text-center">
              <div className="inline-flex items-center gap-2 px-4 py-2 bg-midnight-lighter/50 rounded-full border border-warm-gold/20">
                <Zap className="w-4 h-4 text-warm-gold" />
                <span className="text-sm text-platinum">點擊右下角按鈕快速記錄交易</span>
              </div>
            </div>
          )}
        </div>
      </div>
    </>
  );
}
