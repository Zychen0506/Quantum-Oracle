import React, { useState, useEffect, useRef } from "react";
import { TradingJournal } from "@/api/entities";
import { InvokeLLM } from "@/api/integrations";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Mic, MicOff, Brain, Save, AlertCircle } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { toast } from "sonner";

const invokeLLMWithRetry = async (params, retries = 3, delay = 1000) => {
  for (let i = 0; i < retries; i++) {
    try {
      return await InvokeLLM(params);
    } catch (error) {
      if (i === retries - 1) {
        throw error; // If it's the last retry, rethrow the error
      }
      // Exponential backoff with jitter (delay * (i + 1) + random small amount)
      await new Promise(res => setTimeout(res, delay * (i + 1) + Math.random() * 500));
      console.warn(`InvokeLLM failed, retrying (${i + 1}/${retries})...`, error);
    }
  }
};

export default function Journal() {
  const [journals, setJournals] = useState([]);
  const [isRecording, setIsRecording] = useState(false);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const recognitionRef = useRef(null);
  const [currentEntry, setCurrentEntry] = useState({ journal_text: "" });

  useEffect(() => {
    loadJournals();
    initializeSpeechRecognition();
    return () => recognitionRef.current?.stop();
  }, []);

  const loadJournals = async () => {
    const data = await TradingJournal.list("-entry_date", 10);
    setJournals(data);
  };

  const initializeSpeechRecognition = () => {
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (SpeechRecognition) {
      const recognition = new SpeechRecognition();
      recognition.lang = 'zh-TW';
      recognition.continuous = true;
      recognition.interimResults = true;
      recognition.onresult = (event) => {
        const transcript = Array.from(event.results).map(result => result[0].transcript).join('');
        setCurrentEntry(prev => ({...prev, journal_text: transcript}));
      };
      recognition.onend = () => setIsRecording(false);
      recognitionRef.current = recognition;
    } else {
      console.warn("Speech Recognition API not supported in this browser.");
    }
  };

  const handleVoiceRecording = () => {
    if (!recognitionRef.current) {
      alert('語音輸入不受支援。');
      return;
    }
    if (isRecording) {
      recognitionRef.current.stop();
    } else {
      recognitionRef.current.start();
      setIsRecording(true);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!currentEntry.journal_text.trim()) return;

    setIsAnalyzing(true);
    let analysis = {};
    try {
      analysis = await invokeLLMWithRetry({
        prompt: `以繁體中文分析此筆外匯交易日誌: "${currentEntry.journal_text}"。提供情緒分數(-1至1)、主要情緒狀態，及簡短的AI分析。`,
        response_json_schema: {
          type: "object", properties: {
            sentiment_score: { type: "number" },
            emotional_state: { type: "string", enum: ["confident", "anxious", "excited", "fearful", "neutral", "greedy", "disciplined"] },
            ai_analysis: { type: "string" }
          }
        }
      });
    } catch (err) {
      console.error("AI分析時發生網路錯誤 (重試後):", err);
      toast.error("AI分析失敗，已儲存基本日誌。", {
        description: "神諭暫時無法連線。請稍後再試。",
        icon: <AlertCircle className="w-4 h-4" />,
      });
      analysis = { sentiment_score: 0, emotional_state: 'neutral', ai_analysis: '分析失敗，請檢查您的網路連線。' };
    }

    await TradingJournal.create({
      ...currentEntry,
      entry_date: new Date().toISOString(),
      ...analysis
    });

    setCurrentEntry({ journal_text: "" });
    setIsAnalyzing(false);
    loadJournals();
    toast.success("日誌已成功儲存至您的聖殿。");
  };

  return (
    <div className="min-h-screen p-4 md:p-8" style={{background: "linear-gradient(135deg, var(--midnight-navy) 0%, var(--midnight-blue) 100%)"}}>
      <div className="max-w-6xl mx-auto">
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2" style={{color: "var(--warm-gold)", textShadow: "0 0 10px rgba(255, 215, 0, 0.3)"}}>
            神諭之聲
          </h1>
          <p className="text-lg" style={{color: "var(--platinum)", textShadow: "0 0 5px rgba(224, 224, 224, 0.2)"}}>
            將您的交易精髓轉化為智慧
          </p>
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <Card 
            className="border-0" 
            style={{
              background: "rgba(26, 35, 50, 0.8)", 
              border: "1px solid rgba(244, 185, 66, 0.3)"
            }}
          >
            <CardHeader>
              <CardTitle className="flex items-center gap-2" style={{color: "var(--warm-gold)"}}>
                <Brain className="w-5 h-5" />
                新增日誌條目
              </CardTitle>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmit} className="space-y-4">
                <Input 
                  value={currentEntry.trade_pair || ''} 
                  onChange={(e) => setCurrentEntry(prev => ({...prev, trade_pair: e.target.value}))} 
                  placeholder="貨幣對 (例如：EUR/USD)" 
                  style={{
                    background: "rgba(26, 35, 50, 0.6)", 
                    border: "1px solid rgba(224, 224, 224, 0.2)", 
                    color: "var(--platinum)"
                  }}
                />
                <Input 
                  type="number" 
                  value={currentEntry.profit_loss || ''} 
                  onChange={(e) => setCurrentEntry(prev => ({...prev, profit_loss: e.target.value}))} 
                  placeholder="盈虧 ($)" 
                  style={{
                    background: "rgba(26, 35, 50, 0.6)", 
                    border: "1px solid rgba(224, 224, 224, 0.2)", 
                    color: "var(--platinum)"
                  }}
                />
                <div className="relative">
                  <Textarea 
                    value={currentEntry.journal_text} 
                    onChange={(e) => setCurrentEntry(prev => ({...prev, journal_text: e.target.value}))} 
                    placeholder="描述您的交易、思緒和情緒..." 
                    rows={8} 
                    className="resize-none pr-12" 
                    style={{
                      background: "rgba(26, 35, 50, 0.6)", 
                      border: "1px solid rgba(224, 224, 224, 0.2)", 
                      color: "var(--platinum)"
                    }}
                  />
                  <Button
                    type="button"
                    size="icon"
                    variant="ghost"
                    onClick={handleVoiceRecording}
                    className={`absolute top-2 right-2 rounded-full transition-all ${isRecording ? 'text-red-500 animate-pulse' : 'text-gray-400'}`}
                  >
                    {isRecording ? <MicOff className="w-5 h-5" /> : <Mic className="w-5 h-5" />}
                  </Button>
                </div>
                <Button 
                  type="submit" 
                  disabled={isAnalyzing || !currentEntry.journal_text?.trim()} 
                  className="w-full transition-all duration-300 font-semibold"
                  style={{
                    background: isAnalyzing 
                      ? "rgba(74, 144, 226, 0.5)" 
                      : "linear-gradient(135deg, var(--warm-gold) 0%, var(--gold-accent) 100%)", 
                    color: isAnalyzing ? "var(--platinum)" : "var(--midnight-navy)",
                    border: "1px solid var(--warm-gold)"
                  }}
                >
                  {isAnalyzing ? (
                    <>
                      <Brain className="w-4 h-4 mr-2 animate-pulse" />
                      分析中...
                    </>
                  ) : (
                    <>
                      <Save className="w-4 h-4 mr-2" />
                      儲存並分析
                    </>
                  )}
                </Button>
              </form>
            </CardContent>
          </Card>
          
          <Card 
            className="border-0" 
            style={{
              background: "rgba(26, 35, 50, 0.8)", 
              border: "1px solid rgba(74, 144, 226, 0.3)"
            }}
          >
            <CardHeader>
              <CardTitle className="flex items-center gap-2" style={{color: "var(--tech-blue)"}}>
                近期洞見
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4 max-h-[500px] overflow-y-auto">
                <AnimatePresence>
                  {journals.map((journal) => (
                    <motion.div 
                      key={journal.id} 
                      initial={{ opacity: 0, y: 20 }} 
                      animate={{ opacity: 1, y: 0 }} 
                      exit={{ opacity: 0, y: -20 }} 
                      transition={{ duration: 0.2 }} 
                      className="p-4 rounded-lg border" 
                      style={{
                        background: "rgba(26, 35, 50, 0.6)", 
                        border: "1px solid rgba(224, 224, 224, 0.1)"
                      }}
                    >
                      <div className="flex justify-between items-start mb-2">
                        <span className="font-semibold" style={{color: "var(--warm-gold)"}}>
                          {journal.trade_pair}
                        </span>
                        <span className={`text-sm font-semibold ${(journal.profit_loss || 0) >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                          {journal.profit_loss !== undefined && journal.profit_loss !== null 
                            ? `$${journal.profit_loss.toFixed(2)}` 
                            : 'N/A'}
                        </span>
                      </div>
                      <p className="text-sm mb-3 opacity-90 line-clamp-2" style={{color: "var(--platinum)"}}>
                        {journal.journal_text}
                      </p>
                      {journal.ai_analysis && (
                        <div 
                          className="p-3 rounded-lg text-xs" 
                          style={{
                            background: "rgba(74, 144, 226, 0.1)", 
                            border: "1px solid rgba(74, 144, 226, 0.3)"
                          }}
                        >
                          <strong style={{color: "var(--tech-blue)"}}>神諭：</strong> 
                          <span style={{color: "var(--platinum)"}}>
                            {journal.ai_analysis}
                          </span>
                        </div>
                      )}
                    </motion.div>
                  ))}
                </AnimatePresence>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}