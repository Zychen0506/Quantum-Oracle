import React, { useState, useEffect, useCallback } from "react";
import { TradingJournal, RiskProfile } from "@/api/entities";
import { InvokeLLM } from "@/api/integrations";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Brain, RefreshCw, WifiOff } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

// 備用策略數據
const generateFallbackStrategies = (profileData) => {
  const baseStrategies = [
    {
      name: "量子波動捕獵者",
      type: "conservative",
      description: "專注於低風險、穩定收益的保守型策略。運用AI技術識別市場中的微小波動機會，透過精準的進出場時機，在控制風險的前提下獲得穩定報酬。適合風險厭惡型投資者，年化目標收益10-15%。"
    },
    {
      name: "黃金比例執行者",
      type: "balanced",
      description: "結合技術分析與基本面分析的平衡策略。採用黃金分割比例進行倉位管理，在風險與收益間取得最佳平衡。運用多時間框架分析，捕捉中長期趨勢機會，年化目標收益15-25%。"
    },
    {
      name: "神諭趨勢獵鷹",
      type: "aggressive",
      description: "高風險高收益的積極型策略。運用深度學習算法預測市場趨勢，快速響應市場變化。採用動態槓桿調整和嚴格的風控機制，追求最大化收益。適合經驗豐富的交易者，年化目標收益25-40%。"
    }
  ];

  // 根據用戶檔案調整策略
  if (profileData?.journals?.length > 0) {
    const avgSentiment = profileData.journals.reduce((sum, j) => sum + (j.sentiment_score || 0), 0) / profileData.journals.length;
    const riskScore = profileData.riskProfile?.overall_risk_score || 50;
    
    // 根據情緒和風險調整策略描述
    if (avgSentiment > 0.3) {
      baseStrategies[2].description += " 考量到您的樂觀交易風格，建議在趨勢確認後積極加倉。";
    } else if (avgSentiment < -0.3) {
      baseStrategies[0].description += " 鑒於您謹慎的交易性格，建議採用更保守的止損策略。";
    }

    if (riskScore > 70) {
      baseStrategies[2].description += " 符合您的高風險容忍度，可考慮適度增加槓桿使用。";
    }
  }

  return baseStrategies;
};

const invokeLLMWithRetry = async (params, retries = 3, delay = 2000) => {
  for (let i = 0; i < retries; i++) {
    try {
      return await InvokeLLM(params);
    } catch (error) {
      if (i === retries - 1) throw error;
      console.log(`策略生成重試 ${i + 1}/${retries}...`);
      await new Promise(res => setTimeout(res, delay * (i + 1)));
    }
  }
};

export default function Strategy() {
  const [strategies, setStrategies] = useState([]);
  const [isGenerating, setIsGenerating] = useState(false);
  const [userProfileData, setUserProfileData] = useState(null);
  const [error, setError] = useState(null);
  const [dataSource, setDataSource] = useState('live');
  
  const generateStrategy = useCallback(async (profileData) => {
    setError(null);
    try {
      // 簡化用戶資料以避免 JSON 過於龐大
      const simplifiedProfile = {
        journalCount: profileData.journals?.length || 0,
        avgSentiment: profileData.journals?.length > 0 
          ? profileData.journals.reduce((sum, j) => sum + (j.sentiment_score || 0), 0) / profileData.journals.length 
          : 0,
        riskScore: profileData.riskProfile?.overall_risk_score || 50,
        tradingStyle: profileData.riskProfile?.position_sizing || 'moderate',
        recentEmotions: profileData.journals?.slice(0, 3).map(j => j.emotional_state).join(', ') || 'unknown'
      };

      const response = await invokeLLMWithRetry({
        prompt: `以繁體中文為一位菁英交易者生成3種個人化外匯交易策略（保守型、平衡型、積極型）。交易者資料摘要：日誌條目${simplifiedProfile.journalCount}筆，平均情緒分數${simplifiedProfile.avgSentiment.toFixed(2)}，風險分數${simplifiedProfile.riskScore}，交易風格${simplifiedProfile.tradingStyle}，近期情緒狀態：${simplifiedProfile.recentEmotions}。對於每種策略，提供一個精緻的名稱、核心方法論和關鍵參數。策略應該具體、可操作，並反映用戶的交易風格和風險偏好。`,
        add_context_from_internet: true,
        response_json_schema: {
          type: "object",
          properties: {
            strategies: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  name: { type: "string" },
                  type: { type: "string" },
                  description: { type: "string" }
                },
                required: ["name", "type", "description"]
              }
            }
          },
          required: ["strategies"]
        }
      });
      
      setStrategies(response.strategies || []);
      setDataSource('live');
    } catch (err) {
      console.error("策略生成失敗，使用備用策略:", err);
      
      // 使用備用策略
      const fallbackStrategies = generateFallbackStrategies(profileData);
      setStrategies(fallbackStrategies);
      setDataSource('fallback');
      setError("已載入精心設計的備用策略。網路連線恢復後將提供更個人化的建議。");
    }
  }, []);

  const loadDataAndGenerate = useCallback(async () => {
    setIsGenerating(true);
    setError(null);
    try {
      const [journals, riskProfiles] = await Promise.all([
        TradingJournal.list("-entry_date", 20), 
        RiskProfile.list("-profile_date", 1)
      ]);
      const profile = { journals, riskProfile: riskProfiles[0] };
      setUserProfileData(profile);
      await generateStrategy(profile);
    } catch (error) {
      console.error('載入資料時出錯:', error);
      // 即使無法載入用戶資料，也提供通用策略
      const fallbackStrategies = generateFallbackStrategies(null);
      setStrategies(fallbackStrategies);
      setDataSource('fallback');
      setError("已提供通用策略建議。");
    }
    setIsGenerating(false);
  }, [generateStrategy]);

  useEffect(() => {
    loadDataAndGenerate();
  }, [loadDataAndGenerate]);

  const handleRegenerate = useCallback(() => {
    if (userProfileData) {
      setIsGenerating(true);
      setError(null);
      generateStrategy(userProfileData).finally(() => setIsGenerating(false));
    } else {
      loadDataAndGenerate();
    }
  }, [userProfileData, generateStrategy, loadDataAndGenerate]);

  return (
    <div className="min-h-screen p-4 md:p-8">
      <div className="max-w-7xl mx-auto">
        <div className="mb-8 flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold mb-2" style={{color: "var(--silver-light)"}}>策略法典</h1>
            <p className="opacity-70" style={{color: "var(--silver)"}}>由量子智能生成的個人化策略</p>
            
            {/* 數據源指示器 */}
            <AnimatePresence>
              {dataSource !== 'live' && (
                <motion.div
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  className="flex items-center gap-2 mt-2"
                >
                  <WifiOff className="w-4 h-4 text-yellow-500" />
                  <span className="text-xs text-yellow-400">
                    {dataSource === 'fallback' ? '使用備用策略庫' : '離線模式'}
                  </span>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
          
          <Button 
            onClick={handleRegenerate} 
            disabled={isGenerating} 
            className="transition-all duration-300 glow-gold" 
            style={{background: "linear-gradient(135deg, var(--gold) 0%, var(--gold-light) 100%)", color: "#000"}}
          >
            {isGenerating ? 
              <>
                <Brain className="w-4 h-4 mr-2 animate-pulse" />
                生成中...
              </> : 
              <>
                <RefreshCw className="w-4 h-4 mr-2" />
                重新生成
              </>
            }
          </Button>
        </div>
        
        <AnimatePresence>
          {error && (
            <motion.div 
              initial={{ opacity: 0 }} 
              animate={{ opacity: 1 }} 
              exit={{ opacity: 0 }} 
              className="mb-6 p-4 rounded-lg border border-yellow-500/30 bg-yellow-500/10 text-yellow-300"
            >
              <div className="flex items-center gap-3">
                <Brain className="w-5 h-5" />
                <span>{error}</span>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* 策略卡片 */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <AnimatePresence>
            {strategies.map((strategy, index) => (
              <motion.div 
                key={strategy.name} 
                initial={{ opacity: 0, y: 20 }} 
                animate={{ opacity: 1, y: 0 }} 
                transition={{ delay: index * 0.1 }}
              >
                <Card 
                  className="border-0 transition-all duration-500 hover:glow-gold h-full" 
                  style={{
                    background: "rgba(42, 42, 42, 0.3)", 
                    border: "1px solid rgba(212, 175, 55, 0.2)"
                  }}
                >
                  <CardHeader>
                    <div className="flex items-center justify-between mb-2">
                      <CardTitle className="text-lg" style={{color: "var(--silver-light)"}}>
                        {strategy.name}
                      </CardTitle>
                      
                      {/* 數據源標籤 */}
                      {dataSource !== 'live' && (
                        <div className="px-2 py-1 rounded text-xs" style={{
                          background: "rgba(255, 193, 7, 0.2)",
                          color: "#ffc107"
                        }}>
                          備用
                        </div>
                      )}
                    </div>
                    
                    <div 
                      className="text-sm capitalize font-semibold" 
                      style={{
                        color: strategy.type === 'conservative' ? 'var(--ethereal-blue)' : 
                               strategy.type === 'aggressive' ? 'red' : 'var(--gold)'
                      }}
                    >
                      {strategy.type === 'conservative' ? '保守型' : 
                       strategy.type === 'aggressive' ? '積極型' : '平衡型'}
                    </div>
                  </CardHeader>
                  
                  <CardContent>
                    <p className="text-sm opacity-80 leading-relaxed" style={{color: "var(--silver)"}}>
                      {strategy.description}
                    </p>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </AnimatePresence>
        </div>

        {/* 載入狀態 */}
        <AnimatePresence>
          {isGenerating && strategies.length === 0 && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="flex items-center justify-center py-12"
            >
              <div className="text-center">
                <Brain className="w-12 h-12 mx-auto mb-4 animate-pulse" style={{color: "var(--gold)"}} />
                <p className="text-lg font-medium" style={{color: "var(--silver-light)"}}>
                  量子智能正在為您鍛造專屬策略...
                </p>
                <p className="text-sm opacity-60 mt-2" style={{color: "var(--silver)"}}>
                  分析您的交易模式與風險偏好
                </p>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}